#!/bin/sh
repname=neuro-stat
if [ \( -e $repname \) -a \( -e $repname/v3/src/wink_mam4/wink.R \) -a \( -e $repname/v3/src/wink_mam4/wink.so \) ]
then
    echo "Ok, neuro-stat code is installed in $repname directory"
    echo
else
    rm -fr $repname
    git clone --quiet https://daemon@git.math.cnrs.fr:/anon/forge/neuro-stat
    cd $repname/neurocorr;make update -s;cd v4;make -s;cd ../../v3/src/wink_mam4/;make -s
if [ \(  -e $repname \) -a \(  -e $repname/v3/src/wink_mam4/wink.R \) -a \(  -e $repname/v3/src/wink_mam4/wink.so \) ]
then
    echo 'ABORT!!!!'
else
    echo
    echo
    echo "neuro-stat code is now installed in $repname directory"
fi
fi
