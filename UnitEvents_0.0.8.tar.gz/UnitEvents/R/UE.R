                                        # To identify Unitary Events
                                        # There are repetitions
                                        #findUE <- function(A, DataNeur, delay, DNVersion="matrix")
findUE <- function(A, DataNeur, delay)
{

    c1 = c2 = c()  #initialization
    if(length(A))
        {
            c1 = matrix(nrow=5, ncol=0); c2 = c1

            n = nrow(DataNeur)  # even value 
            F1 = DataNeur[1:(n/2),]
            F2 = DataNeur[(n/2+1):n,]

            ntrials <- nrow(F1)  #number of trials
                                        #  print(dim(A))

            toprint = vector('list', n*ncol(DataNeur))
            ic = 0
            for (i in 1:ntrials)
                {
                    t1 <- F1[i,-1]
                    t2 <- F2[i,-1]
                    l1 <- F1[i,1] #length(t1)
                    l2 <- F2[i,1] #length(t2)
                    if ((l1*l2)!=0)
                        {
                            for (j in (1:l1))
                                {
                                    t1j <- t1[j]   # spike of the 1st neuron
                                    zt <- (A[1,]<=t1j)*(t1j<=A[2,])  #vector of size ncol(A)
                                    ind1jA <- which(zt==1)  #neuron 1, trial i, spike j, window A (time window indices of A containing t1j)
                                        #                                    if (length(ind1jA)!=0)
                                    for (k in ind1jA)
                                        {
                                            u1 <- max(t1j-delay, A[1,k])
                                            v1 <- min(t1j+delay, A[2,k])
#					    print(c(t1j-delay,t1j+delay,k,ind1jA,zt,A[1,k], A[2,k],u1,v1))
                                            cc <- (u1<=t2[1:l2])*(t2[1:l2]<=v1) #neuron 2, trial i, 
                                        #                                            if(length(unique(A[3,ind1jA]))>1) warning('UE with two signs!!')
                                            wcc <- which(cc==1)
                                            if (length(wcc)!=0)
                                                {
 #                                                    print(c(t2[wcc],t1j,A[1,k], A[2,k]))
                                                    c1 = cbind(c1, c(t1j, i, A[3,k], A[1,k], A[2,k]))
                                        #                                                    c2 = cbind(c2, rbind(t2[wcc], rep(ntrials+1+i,length(wcc)), rep(A[3,k], length(wcc))))
                                                    c2 = cbind(c2, rbind(t2[wcc], rep(i,length(wcc)), rep(A[3,k], length(wcc)), rep(A[1,k], length(wcc)), rep(A[2,k], length(wcc))))
                                        #                                                    toprint[[(i-1)*ncol(DataNeur)+j]] = c(i, t1j, t2[wcc], u1, v1, A[3,ind1jA[1]])
                                                    ic = ic+1
                                                    toprint[[ic]] = c(i, t1j, t2[wcc], A[1,k], A[2,k], A[3,k])
                                                }
                                            
                                        }
                                }
                        }
                }
            if(length(toprint)) {
                                        #                toprint2 = Reduce(rbindfill2, toprint)	    
                toprint = Reduce(rbindfill2, toprint)	    
                                        #                print(length(toprint))
                                        #                                        print(length(toprint2))
                                        #                                        print(is(toprint2))
                write.table(toprint, file='UE.csv', sep=';', row.names=FALSE, col.names=FALSE)
            }
                                        #            else
                                        #                print('toprint est vide')
		rownames(c1) <- c('N1 spikes','trial index','detection type', 'start of time window', 'end of time window')
		rownames(c2) <- c('N2 spikes','trial index','detection type', 'start of time window', 'end of time window')
        }
                                        #  print(c1)
                                        #  print('---------------------------------------')
                                        #  print(c2)
                                        #  print('---------------------------------------')
                                        #    write.table(t(c1), file='UE_Neur1.csv', sep=';', row.names=FALSE, col.names=c('spike time', 'trial', 'type'))
                                        #    write.table(t(c2), file='UE_Neur2.csv', sep=';', row.names=FALSE, col.names=c('spike time', 'trial', 'type'))
                                        #    print('length c1')
                                        #    print(c(length(c1), length(c2)))
    return(list(N1=c1, N2=c2))
}


                                        # To test two outputs of UnitEvents (each one with fields A and UE)
isequalUE <- function (xns, xpaf) 
{
    if(match(FALSE,dim(xns$A)==dim(xpaf$A),'nomatch'=FALSE)) {
        warning('Wrong dimensions for detected time windows')  #
        return(FALSE)
    }
    if(match(FALSE,dim(xns$UE$N1)==dim(xpaf$UE$N1),'nomatch'=FALSE)) {
        warning('Wrong dimensions for Neuron 1')  #
        return(FALSE)
    }
    if(match(FALSE,dim(xns$UE$N2)==dim(xpaf$UE$N2),'nomatch'=FALSE)) {
        warning('Wrong dimensions for Neuron 2')  #
        return(FALSE)
    }
    T1 = sum(xns$A==xpaf$A)==length(xns$A) 
    T2 = sum(xns$UE$N1==xpaf$UE$N1)==length(xns$UE$N1)
    T3 = sum(xns$UE$N2==xpaf$UE$N2)==length(xns$UE$N2)
    if(T1&&T2&&T3) return(TRUE)
    else
        return(FALSE)
}


                                        #own rbind
                                        #rbind and fill missing columns with 0
rbindfill2 <- function(a, b)
{
    if (is.null(a)) { 
        a = matrix(nrow=0,ncol=0)
        nca = 0
    } else
        {
            if(is.vector(a))
                nca = length(a)
            else
                nca = ncol(as.matrix(a)) 
        }
    if (is.null(b)) { 
        b = matrix(nrow=0,ncol=0)
        ncb = 0
    } else
        {
            if(is.vector(b))
                ncb = length(b)
            else
                ncb = ncol(as.matrix(b)) 
        }
    
                                        #	nca = length(a); ncb = length(b)
                                        #   print(c(nca,ncb))
    if((nca==0) && (ncb==0))
                                        #	  return(c())
        return(matrix(nrow=0,ncol=0))
    else
        {	  
            m = max(nca,ncb)
            if(nca<m)
                {	      
                    if(nca==0)
                        a = c()
                    else
                        {
                            if(is.vector(a))
                                a = c(a, rep(0,m-nca))
                            else
                                a = cbind(as.matrix(a), matrix(0,nrow=nrow(a), ncol=(m-nca)))
                        }
                }
            if(ncb<m)
                {
                    if(ncb==0)
                        b = c()
                    else {
                        if(is.vector(b))
                            b = c(b, rep(0,m-ncb))
                        else

                            b = cbind(as.matrix(b), matrix(0,nrow=nrow(b), ncol=(m-ncb)))
                    }
                }
                                        #            print(a)
                                        #            print(b)
            return(suppressWarnings(rbind(a,b)))
        }
}
