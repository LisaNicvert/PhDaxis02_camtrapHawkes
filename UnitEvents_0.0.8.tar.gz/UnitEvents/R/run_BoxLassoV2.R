#source('BoxLassoV2.R')
#source('mesplots.R')
#source('createDN.R')
options(digits=15)
getComputerName <- function() { return(Sys.info()[4][[1]]) } 
getOS <- function() { return(Sys.info()[1][[1]]) } 

getSoftware <- function() { return(list(Softname='R', Release=paste(R.version$major, R.version$minor, sep='.') )) }


getUserName <- function() { return(Sys.info()[7][[1]]) } 


# Computation of G, b, mu2, muA matrices and computation of the estimation using different Lasso solvers
# Errors between methods are displayed
# Computation times are printed on the screen
# Matrices and estimators are saved into a .RData file
# input_dir could be an empty string (for an absolute path for ficname)
#

run_BoxLassoV2<- function(M, k=5, del=0.02, gamma=3, Z=0.15, BoxEst=matrix(c(1,0,20,1),nrow=4), scale=1e15, threads=1, Ntrial=1, ficname="draw_", output_dir="results", methods=c("all"), is.RData=TRUE, is.dataneur=TRUE, saving.matrices=FALSE)
{
  # to change default value of the input file using the value of M
  if(ficname=="draw_")
  {
    if((!is.RData)) # it is a .dat file
    {
      ficname = paste(ficname, M, '.dat', sep='')
    }
    else # it is a .RData file
    {
      ficname = paste(ficname, M, '.RData', sep='')
    }}
  
  method_list = c("neurocorr")
  if(!is.RData) {
    IS=list()
  }
  if((length(methods)==1) && (tolower(methods)=="all"))
  {
    methods = method_list
  }
  t0 = proc.time()  #start
  dir.create(output_dir, showWarnings=FALSE)
  #print(M)
  #print(length(M))
  #print(is(M))
  if((!is.RData)) # .dat file
  {
    # previous version
    #        DNfile = paste(input_dir, .Platform$file.sep, ficname, M, '.dat', sep='')
    #        DNfile = paste(input_dir, .Platform$file.sep, ficname, sep='')
    DNfile = ficname
    
    if(is.dataneur) {
      DN = read.table(DNfile)
    }
    else
    {
      DN = createDN(DNfile)
    }
  }
  else # .RData file
  {
    # previous version
    #        DNfile = paste(input_dir, .Platform$file.sep, ficname, M, '.RData', sep='')
    # DNfile should end with .RData
    #        DNfile = paste(input_dir, .Platform$file.sep, ficname, sep='')
    DNfile = ficname
    load(DNfile)
  }
  #    BoxEst = rbind(1:Ntrial, matrix(rep(c(0,Tend,1),Ntrial),nrow=3))
  #print(dim(DN))
  print('')
  print(paste('Estimation test for', M, 'neurons'))
  print(paste('hostname =', getComputerName()))
  print(paste('OS =', getOS()))
  print(paste('user =', getUserName()))
  print(paste(getSoftware()$Softname, getSoftware()$Release))
  print(paste('Date', date()))
  print('')
  print(paste('DataNeur file is', DNfile))
  print(paste('k = ', k, ', del = ', del, ', gamma = ', gamma, ', Z = ', Z, sep=''))
  #    print('BoxEst =')
  #    print(BoxEst)
  options(digits=10) # pour avoir plus de chiffres apres la virgule
  #    write(t(DN), 'DN.txt', ncolumns=ncol(DN))
  t1 = proc.time()
  #GbVB = NeuroCorr_Compute(DN, M, scale, del, k, BoxEst, "byKind", threads=1)
  GbVB = NeuroCorr_Compute(DN, as.numeric(M), scale, del, k, BoxEst, "byKind")
  mat_time = (proc.time()-t1)[3]
  # si millisecondes
  #    GbVB$G[[1]] = GbVB$G[[1]]/1000.
  if(saving.matrices)
      {
  write(t(GbVB$mu1[[1]]), paste(output_dir, .Platform$file.sep, "b_K=", k, "_M=", M, ".txt", sep=''), ncolumns=ncol(GbVB$mu1[[1]]))
  write(t(GbVB$G[[1]]), paste(output_dir, .Platform$file.sep, "G_K=", k, "_M=", M, ".txt", sep=''), ncolumns=ncol(GbVB$G[[1]]))
  write(t(GbVB$mu2[[1]]), paste(output_dir, .Platform$file.sep, "mu2_K=", k, "_M=", M, ".txt", sep=''), ncolumns=ncol(GbVB$mu2[[1]]))
  write(t(GbVB$muA[[1]]), paste(output_dir, .Platform$file.sep, "muA_K=", k, "_M=", M, ".txt", sep=''), ncolumns=ncol(GbVB$muA[[1]]))
}
  Lasso = BoxLassoV2(GbVB, del, k, gamma, Z, methods=methods)

  if(saving.matrices)
      {
  write(t(Lasso$BL[[1]]), paste(output_dir, .Platform$file.sep, "eventBL_K=", k, "_M=", M, ".txt", sep=''), ncolumns=ncol(Lasso$BL[[1]]))
  write(t(Lasso$BOL[[1]]), paste(output_dir, .Platform$file.sep, "eventBOL_K=", k, "_M=", M, ".txt", sep=''), ncolumns=ncol(Lasso$BOL[[1]]))
}
  
  if(is.element("neurocorr", tolower(methods))) {
    IS[[length(IS)+1]] = coeff2interac(Lasso$BL, k, del)
    if(length(IS)>1) {
      err = compute_errors(IS[[1]], IS[[2]])
      print('')
      print(paste('Error between BL and exact: spontaneous part', err[[1]], ', interaction function error', err[[2]]))}
    
    IS[[length(IS)+1]] = coeff2interac(Lasso$BOL, k, del)
    if(length(IS)>2) {
      err = compute_errors(IS[[1]], IS[[3]])
      print(paste('Error between BOL and exact: spontaneous part', err[[1]], ', interaction function error', err[[2]]))}
    
    IS[[length(IS)+1]] = coeff2interac(Lasso$BVL, k, del)
    if(length(IS)>3) {
      err = compute_errors(IS[[1]], IS[[4]])
      print(paste('Error between BVL and exact: spontaneous part', err[[1]], ', interaction function error', err[[2]]))}
  }
  
    print('')
  
    print('Respective times')
  tot_time = (proc.time()-t0)[3]
  print(paste('Total time of the simulation', tot_time))
  print(paste('Time to construct matrices for the Lasso problem', mat_time))
  if(is.element("neurocorr", tolower(methods))) {
    print(paste('Computation time for BL', Lasso$times[["BL"]]))
    print(paste('Computation time for BOL', Lasso$times[["BOL"]]))
    print(paste('Computation time for BVL', Lasso$times[["BVL"]]))
  }
  
  #    save(GbVB, mat_time, Lasso, tot_time, file=paste(output_dir, .Platform$file.sep, 'sol_',M,'.RData',sep=''))
  return(list(Lasso, mat_time, tot_time))
}
