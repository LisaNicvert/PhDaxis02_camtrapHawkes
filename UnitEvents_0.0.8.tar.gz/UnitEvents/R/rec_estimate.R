#library(igraph)
#source('run_BoxLassoV2.R')
#source('mesplots.R')
#source('get_network.R')
#
# freq = firing rate ?
#
get_neur<-function(i, K)
{
    chi = i %/% K
    if( (i - K*chi)==0)
        return(chi)
    else
        return(chi+1)
}

get_adjacency_matrix_from_fullspec<-function(fname)
{
                                        #recuperer partout ou la connection est  "1"
    tab = read.table(fname, header=T, sep=",")
    Nneur = as.integer(sqrt(nrow(tab)))
#    print(paste('Nneur=',Nneur))
    stopifnot(Nneur*Nneur==nrow(tab))
    ll = which(tab$connection==T)
                                        # ordre est le suivant: influence de 0 sur 0, de 0 sur 1, de 0 sur 2, ....
                                        #
    M = matrix(FALSE, ncol=Nneur, nrow=Nneur)
                                        # de 1 a 8, c'est le 1er neurone (0)
                                        # de 9 à 16, c'est le 2eme (1)
                                        #
    for(indx in ll)
        {
                                        # influence de i sur j
            i = (indx-1) %/% Nneur 
            j = indx -1 - i*Nneur + 1  # en R, numerotation commence a 1
            i = i + 1
            M[i,j] = TRUE
        }
    P = layout_with_fr(graph_from_adjacency_matrix(M))
    fname2 = paste("layout_M=", Nneur, ".layout", sep='')
    write(t(P), fname2, ncolumns=2)
    return(M)
}

make_estimated_adjacency_matrix<-function(M, K, BL, resu_dir)
{
    # M, K, output_dir
    fname = paste(resu_dir, .Platform$file.sep, "eventBOL_K=", K, "_M=", M, "_Ncomp=1.mat", sep='')
    epsilon = 1e-15
    locations = matrix(ncol=2, nrow=0)
    values = c()
    #tester M=1
    n_rows = dim(BL)[1]
    print(n_rows)
    for(i in seq_len(M))
    {
        lest = c()
        ll = which(abs(BL[2:n_rows,i])>epsilon, arr.ind=T)
#        print('-----------------------')
#        print(paste('i=',i))
#        print(ll)
        for(ait in ll)
        {
            neu = get_neur(ait, K)
#            print(paste("neu=",neu))
            lest = c(lest, neu)
        }
        lest = unique(lest)
        for(ait in lest)
        {
            locations = rbind(locations, c(ait,i))
            values = c(values, 1)
        }
    }
    spM = matrix(0, nrow=M, ncol=M)
    if(length(values))
    {
        for(j in seq_len(length(values))) {
            spM[locations[j,1], locations[j,2]] = values[j] 
        }
    }

    P = layout_with_fr(graph_from_adjacency_matrix(spM))
    fname = paste(resu_dir, .Platform$file.sep, "layout_K=", K, "_M=", M, ".layout", sep='')
    write(t(P), fname, ncolumns=2)
    return(spM)
}


rec_estimate <- function(M, k=2, del=0.02, Tend=20, event_file_name, full_spec_file="", comp_file="", names=c(), output_dir="results", gamma=3, saving.matrices=FALSE, methods=c()) {
    if(!length(methods)) {
        methods = c("neurocorr", "lshoot")
    }
    
    print('------------')
    print(event_file_name)
    print('------------')
    flush.console()
    #input_dir d'interet douteux
    exists_comp_file = length(comp_file) && (file.exists(comp_file))
    if(exists_comp_file) {
        BoxEst = t(as.matrix(read.table(comp_file, sep=",", header=T)))
    }    else	       
    {
        Ntrial = 1
        BoxEst = rbind(1:Ntrial, matrix(rep(c(0,Tend,1),Ntrial),nrow=3))
    }
    
    # boucle sur les boites
    LL = run_BoxLassoV2(M, k=k, del=del, gamma=gamma, BoxEst=BoxEst, ficname=event_file_name, output_dir=output_dir, methods=methods, is.RData=FALSE, is.dataneur=FALSE, saving.matrices=saving.matrices)
    Lasso = LL[[1]]
    mat_time = LL[[2]]
    tot_time = LL[[3]]
    eps = 1e-9
    #    print(which(abs(Lasso$LARS[[1]])>eps, arr.ind=T))
    ITT = list()
    #    print(full_spec_file)
    exists_network = length(full_spec_file) && (file.exists(full_spec_file))
    
    if(exists_network) {
        ITT[[1]] = get_network(M, full_spec_file)
    }    else	       
    {
        ITT[[1]] = list()
    }   
    # ITT[[2]] = coeff2interac(Lasso$LARSBOL, k, del)
    ITT[[2]] = coeff2interac(Lasso$BOL, k, del)
    IS = vector("list", length=2)
    if(exists_network) {
        IS[[1]] = vector("list", length=2)
        names(IS[[1]]) = c("S", "I")
        IS[[1]]$I = array(c(list()), c(M,M,1))
        for(i in seq_len(M)) {
            for(j in seq_len(M)) {
                IS[[1]]$I[i,j,1][[1]] = ITT[[1]]$I[j,i,1][[1]] 
            }
        }
        IS[[1]]$S = ITT[[1]]$S
    }
    IS[[2]] = ITT[[2]]
    #    print('IS[[1]] <=> EXACT ')
    #    for(i in seq_len(M)) {
    #        for(j in seq_len(M)) {
    #            print(c(i,j))
    #            print(IS[[1]]$I[i,j,1][[1]])
    #        }
    #    }
    #    print('-------------------------------------------------')
    #    print('-------------------------------------------------')
    #    print('IS[[2]] <=> BOL ')
    #    for(i in seq_len(M)) {
    #        for(j in seq_len(M)) {
    #            print(c(i,j))
    #            print(IS[[2]]$I[i,j,1][[1]])
    #        }
    #    }
    dir.create(output_dir, showWarnings=FALSE)
    make_estimated_adjacency_matrix(M, k, Lasso$BOL[[1]], output_dir)
                                        #    save(mat_time, Lasso, tot_time, IS, file=paste(output_dir, .Platform$file.sep, 'solV2_',M,'.RData',sep=''))
    options(digits=15)
    for(Ncomp in seq_len(length(Lasso$BL))) {
        write(c(M,k,del), paste(output_dir, .Platform$file.sep, "eventBL_K=", k, "_M=", M, "_Ncomp=", Ncomp, ".mat", sep=''))
        write(c(M,k,del), paste(output_dir, .Platform$file.sep, "eventBOL_K=", k, "_M=", M, "_Ncomp=", Ncomp, ".mat", sep=''))
        write(t(Lasso$BL[[Ncomp]]), paste(output_dir, .Platform$file.sep, "eventBL_K=", k, "_M=", M, "_Ncomp=", Ncomp, ".mat", sep=''), ncolumns=ncol(Lasso$BL[[Ncomp]]), append=T)
        write(t(Lasso$BOL[[Ncomp]]), paste(output_dir, .Platform$file.sep, "eventBOL_K=", k, "_M=", M, "_Ncomp=", Ncomp, ".mat", sep=''), ncolumns=ncol(Lasso$BOL[[Ncomp]]), append=T)
    }
    if(length(names)) {
        print('aqui')
        flush.console()
        dir.create('figures/', showWarnings=FALSE)
        #        Plot_Hawkesnew(ITT, c('black','red'), tracelegend=c('exact','BOL'), names=paste('figures/', debficname, '_', M, 'initial_order.png', sep=''))
        #        dev.new()
        Plot_Hawkesnew(IS, c('black','red'), tracelegend=c('exact','BOL'), names=paste('figures/', debficname, '_', M, 'transposed_order.png', sep=''))
        #    Plot_graph_Hawkes(IS[[1]], neurnames=c(1:M), vecpres=c(1,1), names=c('exact'))
        #    Plot_graph_Hawkes(IS[[2]], neurnames=c(1:M), vecpres=c(1,1), names=c('BOL'))
    }
}
