                                        # Verifier la version de Cyrille Mascart sous goddess-wip/hawkes/src/main/resources/HawkesSim/mesplots.R
                                        # coeffs est une liste de matrices de tailles (1+Nneur*K)-by-Nneur, nombre de matrics = nombres de comportements

coeff2interac <- function(coeffs, k, del)
{
    Ncomp = length(coeffs)
    Nneur = ncol(coeffs[[1]])
    spontComp = matrix(0, nrow=Nneur, ncol=Ncomp)
    interacComp = array(c(list()), c(Nneur,Nneur,Ncomp))
    for(comp in 1: Ncomp)
    {
        spontComp[,comp] = coeffs[[comp]][1,]
        
        for(i in 1:Nneur)
        {	
            for(j in 1:Nneur)
                interacComp[i,j,comp][[1]] = rbind(c(0:k)*del, c(coeffs[[comp]][(k*(j-1)+2):(k*j+1),i],0))
        }
    }	
    return(list(S=spontComp, I=interacComp)) 
}

                                        #je trace une serie de I et S sur le meme graphe pour chaque comp c'est une liste de I, S comme sortie du truc d'avant

                                        # IS est une liste
                                        # IS[[1]][[1]] ou IS[[1]]$S contient les valeurs theoriques de spontComp
                                        # IS[[1]][[2]] ou IS[[1]]$I contient les valeurs theoriques de interacComp
                                        # IS[[2]][[1]]
Plot_Hawkes<-function(IS, colors, names=c(), neurnames=c(), ww=1, res=10)
{
                                        # try to test neurnames  neither empty, nor equal to 1:Nneur
    N_traces = length(IS) #number of solution types: theoretical, BL, BOL, ...
    stopifnot(N_traces==length(colors))

                                        # 1st plot is for 1st comportment
    Nneur = dim(IS[[1]][[2]])[1]
    Ncomp = dim(IS[[1]][[2]])[3]
    if(length(neurnames)==0)
        neurnames = 1:Nneur
    
    
    for(comp in 1:Ncomp)
    {
        if(length(names)>0)
        {png(filename = names[comp], width=140*Nneur, height=140*Nneur)}
        par(mfrow=c(Nneur, Nneur))
        for(i in 1:Nneur)
        {
            for(j in 1:Nneur)
            {
                
                S_star = paste('Spont', floor(IS[[1]]$S[i,comp]*res)/res)
                I_star = IS[[1]]$I[i,j,comp][[1]]
                xstar = max(I_star[1,])
                ystar_max = max(I_star[2,])
                ystar_min = min(I_star[2,])
                if(N_traces>1)
                {
                    for(t in 2:N_traces)
                    {
                        It = IS[[t]]$I[i,j,comp][[1]]
                        S_star = paste(S_star, floor(IS[[t]]$S[i,comp]*res)/res)
                        xstar = max(xstar, max(It[1,]))
                        ystar_max = max(ystar_max, max(It[2,]))
                        ystar_min = min(ystar_min, min(It[2,]))
                    }
                }
                plot(I_star[1,], I_star[2,], type='s', col=colors[1], main=S_star, xlim=c(0,xstar), ylim=c(min(ystar_min,-ww),max(ystar_max,ww)), xlab=paste('from',neurnames[j],'to',neurnames[i]), ylab='')
                if(N_traces>1)
                {
                    for(t in 2:N_traces)
                    {
                        It = IS[[t]]$I[i,j,comp][[1]]
                        lines(It[1,], It[2,], type='s', col=colors[t])
                    }
                }	
            }
        }
        if(length(names)>0)
        {dev.off()}

    }
}

                                        # to get the l1-norm of a piecewise constant function
                                        #
                                        # M1 is a two-row matrix containing the support of the piecewise constant function on the first row and the values on the second one.
                                        #We have
                                        #  M1 = ( 0 t1 t2 t3)
                                        #       ( g1 g2 g3 0)
                                        #
                                        # means      f = g1 if  0 <= t <= t1
                                        #            f = g2 if  t1 < t <= t2
                                        #            f = g3 if  t2 < t <= t3
                                        #            f = 0  if  t3 < t
                                        #
getl1norm <- function(M1)
{  
    if(is.list(M1)) {
        M1 = matrix(unlist(M1), nrow=2)
    }
    stopifnot(nrow(M1)>=2)
                                        #        print(is(M1))
                                        #        flush.console()
    lv = ncol(M1)
#    print(paste("lv=",lv))
#    print(is(M1))
#    print(M1)
#    flush.console()
    stopifnot(lv>=2)
                                        #        print(lv)
#					print('length(M1)')
#					print(length(M1))
#					print('dim(M1)')
#					print(dim(M1))
#    print(M1[2,(1:(lv-1))])
#    print(M1[2,])
#    flush.console()
    l1norm = sum(abs(M1[2,(1:(lv-1))])*diff(M1[1,]))
    return(l1norm)
}


                                        # to compute the array of L1-norms for a solution
                                        # the output is a vector of "list" of length Ncomp, each element is a 3D array of dimension (N_traces, Nneur, Nneur) containing the l1-norms
tabl1 <- function(IS)
{
    N_traces = length(IS) #nb de types de solutions: theo, BL, BOL
                                        #        Nneur = dim(IS[[1]][[2]])[1]
    Nneur = dim(IS[[1]]$I)[1]
                                        #        print(Nneur)
                                        #        flush.console()
                                        #        Ncomp = dim(IS[[1]][[2]])[3]
    Ncomp = dim(IS[[1]]$I)[3]
    tabl1 = vector("list", length=Ncomp) # size=Ncomp
                                        # on veut transformer IS[[t]][[2]][i,j,comp] en tableau 3D ?[[comp]]$l1[t, i, j] contenant les normes l1
    
    for(comp in seq_len(Ncomp))
    {
        tabl1[[comp]] = array(0, dim=c(N_traces, Nneur, Nneur))
        for(t in seq_len(N_traces))
        {
            for(i in 1:Nneur)
            {
                for(j in 1:Nneur)
                {
                                        #                                        print(paste('ici',j))
                                        #                                        print(dim(IS[[t]][[2]][i,j,comp][[1]]))
                                        #                                        flush.console()
                    tabl1[[comp]][t,i,j] = getl1norm(IS[[t]][[2]][i,j,comp][[1]])
                                        #                                        print(tabl1[[comp]][t,i,j])
                                        #                                        flush.console()
                }
            }
        }
    }
    return(tabl1)
}


                                        #                                        #je trace une serie de I et S sur le meme graphe pour chaque comp c'est une liste de I, S comme sortie du truc d'avant
                                        #
                                        #                                        # IS est une liste
                                        #                                        # IS[[1]][[1]] ou IS[[1]]$S contient les valeurs theoriques de spontComp
                                        #                                        # IS[[1]][[2]] ou IS[[1]]$I contient les valeurs theoriques de interacComp
                                        #                                        # IS[[2]][[1]]
Plot_Hawkesnew <- function(IS, colors, names=c(), neurnames=c(), tracelegend=c(), ww=1, res=10)
{
    N_traces = length(IS) #nb of solution types: theoretical, BL, BOL, ...
    stopifnot(N_traces==length(colors))
                                        #    print('N_traces=')
                                        #    print(N_traces)
                                        #    print(tracelegend[1:N_traces])
                                        #    flush.console()
    t1 = tabl1(IS) # list of arrays of l1-norms, t1[[comp]] is a 3D array

    Nneur = dim(IS[[1]][[2]])[1]
    Ncomp = dim(IS[[1]][[2]])[3]
    if(length(neurnames)==0)
        neurnames = 1:Nneur
    
    eps = 1e-7 #threshold to detect a zero l1-norm

    symbols = c(1, 3, 4, 2, 6, 5) # o + x triangleUp triangleDown losange  - symboldes des types de solution
    if(length(tracelegend)==0) {
        tracelegend = c('exact', 'BL', 'BOL', 'lshoot')}
    
    stopifnot(N_traces <= length(tracelegend))
    for(comp in 1:Ncomp)
    {
        if(length(names)>0)
        {png(filename = names[comp], width=140*Nneur, height=140*Nneur)}

        indx = unique(which(t1[[comp]]>eps, arr.ind=TRUE)[,2:3])  # to get all (i,j) for the graphical representation
                                        #        print(indx)
        indx = indx[order(indx[,1], indx[,2]),]
                                        #        print('indx')
                                        #        print(indx)
                                        #        N = floor(sqrt(nrow(indx)))
                                        #        par(mfrow=c(N, N+1))
        tn = get_n(nrow(indx))
        par(mfrow=c(tn[1], tn[2]))
        for(i in seq_len(nrow(indx)))
        {
                                        #                    par(new=TRUE)
            xstar = -Inf
            ystar_max = -Inf
            ystar_min = Inf
            for(t in seq_len(N_traces))
            {
                S_star ='spont'
                                        #                    S_star = paste('Spont', floor(IS[[t]]$S[i,comp]*10)/10)
                I_star = IS[[t]]$I[indx[i,1],indx[i,2],comp][[1]]
                if(is.list(I_star)) {
                    I_star = matrix(unlist(I_star), nrow=2)
                }
                xstar = max(xstar, max(I_star[1,]))
                ystar_max = max(ystar_max, max(I_star[2,]))
                ystar_min = min(ystar_min, min(I_star[2,]))
            }
            for(t in seq_len(N_traces))
            {                    
                                        #                                    S_star = paste(S_star, floor(IS[[t]]$S[i,comp]*10)/10)

                I_star = IS[[t]]$I[indx[i,1],indx[i,2],comp][[1]]
                if(t==1) {
                    plot(I_star[1,], I_star[2,], type='s', col=colors[t], main=bquote(paste("h"[.(indx[i,2])%->%.(indx[i,1])], ", from neuron ", .(indx[i,2]), " to ", .(indx[i,1]))), xlim=c(0,xstar), ylim=c(min(ystar_min,-ww), max(ystar_max,ww)), xlab="time (s)", ylab="interaction function", pch=symbols[i], cex.main=1.5)
                                        #                                plot(I_star[1,], I_star[2,], type='s', type='b', col=colors[t], main=S_star, xlim=c(0,xstar), ylim=c(min(ystar_min,-ww), max(ystar_max,ww)), xlab=paste('from',neurnames[indx[i,2]],'to',neurnames[indx[i,1]]), ylab='', pch=symbols[i])
                }
                else {
                    lines(I_star[1,], I_star[2,], type='s', col=colors[t], xlab="time (s)", pch=symbols[i], ylab="interaction function")
                }
            }
            if(length(names)>0) {
                legend(x="topright", legend=tracelegend[1:N_traces], lty=rep(1,N_traces), col=colors, bty="n") }
            else {
                    legend(x="topright", legend=tracelegend[1:N_traces], lty=rep(1,N_traces), col=colors, cex=0.5, bty="n", seg.len=.75)
                }
        }
        if(length(names)>0)
        {dev.off()}

    }
}



                                        #dans IS j'ai une liste [[1]] = spontComp, [[2]] = InteracComp, names c'est les noms des comportements dans l'ordre
                                        # neurnames c'est le nom des neurones
                                        # vecpres c'est le vecteur qu'on veut mettre dans par(mfrow=vecpres)
                                        #layout c'est le layout du graphe par defaut
                                        # mask permet de masquer les autointeractions qu'on veut, mettre le noms de neurnames
Plot_graph_Hawkes <- function(IS, names, neurnames, vecpres, scale=10, layout=c(), mask=c())
{
    par(mfrow=vecpres)
    
    spontComp=IS[[1]]
    interacComp=IS[[2]]
    Nneur=nrow(spontComp)
    Ncomp=ncol(spontComp)
    
    comp=1
    
    mescolors=colorRampPalette(c('red','magenta','gold','green','blue'))(Nneur)
    
    nul=which(spontComp[,comp]<10^(-7))
    color=rep('red',Nneur)
    color[nul]=rep('cyan',length(nul))
    
    if(length(mask)>0)
    {
        for(jm in 1:length(mask))
        {
            indm=which(neurnames==mask[jm])
            color[indm]='white'
        }
    }
    
    A=matrix(data=0,ncol=Nneur,nrow=Nneur)
    B=A
    C=A
    
    
    
    for (i in 1:Nneur)
    {
        for (j in 1:Nneur)
        {
            part=interacComp[i,j,comp][[1]][1,]
            valpart=interacComp[i,j,comp][[1]][2,]
            lv=length(valpart)
            l1norm=sum(abs(valpart[1:(lv-1)])*diff(part))
            
            if(l1norm>10^(-10))
            {
                A[j,i]=l1norm
                B[j,i]=j
                C[j,i]=1
            }
        }
    }
    
    if(length(mask)>0)
    {
        for(jm in 1:length(mask))
        {
            indm=which(neurnames==mask[jm])
            A[,indm]=0
            B[,indm]=0
            C[,indm]=0
        }
    }
    
    for (i in 1:Nneur)
    {
        for (j in 1:Nneur)
        {
            if((i!=j)&(C[i,j]==1)&(C[j,i]==1)) # pour que ca fasseun truc courbe en cas de reciproque
            {
                C[j,i]=0.2
                C[i,j]=0.2
            }
        }
    }
    
    g=graph.adjacency(A,weighted=TRUE,mode='directed')
    gcol=graph.adjacency(B,weighted=TRUE,mode='directed')
    gcurv=graph.adjacency(C,weighted=TRUE,mode='directed')
    ind=which(E(gcurv)$weight==1)
    E(gcurv)$weight[ind]=0
    if(length(layout)==0)
    {
        monlayout=layout.fruchterman.reingold(g)
    }else{
        monlayout=layout
    }
    g$layout=monlayout
    plot.igraph(g,vertex.label=neurnames,vertex.color=color,main=names[comp],edge.arrow.size=0.5,edge.width=E(g)$weight*scale,edge.color=mescolors[E(gcol)$weight],edge.curved=E(gcurv)$weight)
    
    
    if(Ncomp>1)
    {
        for(comp in 2:Ncomp)
        {
            nul=which(spontComp[,comp]<10^(-7))
            color=rep('red',Nneur)
            color[nul]=rep('cyan',length(nul))
            
            if(length(mask)>0)
            {
                for(jm in 1:length(mask))
                {
                    indm=which(neurnames==mask[jm])
                    color[indm]='white'
                }
            }
            
            
            A=matrix(data=0,ncol=Nneur,nrow=Nneur)
            B=A
            C=A
            
            for (i in 1:Nneur)
            {
                for (j in 1:Nneur)
                {
                    part=interacComp[i,j,comp][[1]][1,]
                    valpart=interacComp[i,j,comp][[1]][2,]
                    lv=length(valpart)
                    l1norm=sum(abs(valpart[1:(lv-1)])*diff(part))
                    
                    if(l1norm>10^(-10))
                    {
                        A[j,i]=l1norm
                        B[j,i]=j
                        C[j,i]=1
                    }
                }
            }
            
            if(length(mask)>0)
            {
                for(jm in 1:length(mask))
                {
                    indm=which(neurnames==mask[jm])
                    A[,indm]=0
                    B[,indm]=0
                    C[,indm]=0
                    
                }
            }
            for (i in 1:Nneur)
            {
                for (j in 1:Nneur)
                {
                    if((i!=j)&(C[i,j]==1)&(C[j,i]==1)) # pour que ca fasseun truc courbe en cas de reciproque
                    {
                        C[j,i]=0.2
                        C[i,j]=0.2
                    }
                }
            }
            
            
            g=graph.adjacency(A,weighted=TRUE,mode='directed')
            gcol=graph.adjacency(B,weighted=TRUE,mode='directed')
            gcurv=graph.adjacency(C,weighted=TRUE,mode='directed')
            ind=which(E(gcurv)$weight==1)
            E(gcurv)$weight[ind]=0
            
            g$layout=monlayout
            
            plot.igraph(g,vertex.label=neurnames,vertex.color=color,main=names[comp],edge.arrow.size=0.5,edge.width=E(g)$weight*scale,edge.color=mescolors[E(gcol)$weight],edge.curved=E(gcurv)$weight)
            
        }
    }
    
    
}

mygraph <- function(spontComp, interacComp, names, neurnames, scale, monlayout, mask, mescolors)
    {
        Nneur = length(spontComp)
        nul = which(spontComp<10^(-7))
    color = rep('red', Nneur)
    color[nul] = rep('cyan', length(nul))
    
    if(length(mask)>0)
    {
        for(jm in 1:length(mask))
        {
            indm=which(neurnames==mask[jm])
            color[indm]='white'
        }
    }
    
    A=matrix(data=0,ncol=Nneur,nrow=Nneur)
    B=A
    C=A

        for (i in 1:Nneur)
    {
        for (j in 1:Nneur)
        {
            part=interacComp[i,j][[1]][1,]
            valpart=interacComp[i,j][[1]][2,]
            lv=length(valpart)
            l1norm=sum(abs(valpart[1:(lv-1)])*diff(part))
            
            if(l1norm>10^(-10))
            {
                A[j,i]=l1norm
                B[j,i]=j
                C[j,i]=1 #doute sur celui-la si comp=1
            }
        }
    }
    
    if(length(mask)>0)
    {
        for(jm in 1:length(mask))
        {
            indm=which(neurnames==mask[jm])
            A[,indm]=0
            B[,indm]=0
            C[,indm]=0
        }
    }
    
    for (i in 1:Nneur)
    {
        for (j in 1:Nneur)
        {
            if((i!=j)&(C[i,j]==1)&(C[j,i]==1)) # pour que ca fasseun truc courbe en cas de reciproque
            {
                C[j,i]=0.2
                C[i,j]=0.2
            }
        }
    }
    
    g = graph.adjacency(A, weighted=TRUE, mode='directed')
    gcol = graph.adjacency(B, weighted=TRUE, mode='directed')
    gcurv = graph.adjacency(C, weighted=TRUE, mode='directed')
    ind = which(E(gcurv)$weight==1)
    E(gcurv)$weight[ind] = 0
    if(length(monlayout)==0)
    {
        g$layout=layout.fruchterman.reingold(g)
    }else{
        g$layout=monlayout
    }
    plot.igraph(g, vertex.label=neurnames, vertex.color=color, main=names, edge.arrow.size=0.5, edge.width=E(g)$weight*scale, edge.color=mescolors[E(gcol)$weight], edge.curved=E(gcurv)$weight)
}


                                        #dans IS j'ai une liste [[1]] = spontComp, [[2]] = InteracComp, names c'est les noms des comportements dans l'ordre
                                        # neurnames c'est le nom des neurones
                                        # vecpres c'est le vecteur qu'on veut mettre dans par(mfrow=vecpres)
                                        #layout c'est le layout du graphe par defaut
                                        # mask permet de masquer les autointeractions qu'on veut, mettre le noms de neurnames
Plot_graph_Hawkesnew <- function(IS, names, neurnames, vecpres, scale=10, monlayout=c(), mask=c())
{
    par(mfrow=vecpres)
    
    spontComp = IS[[1]]
    interacComp = IS[[2]]
    Nneur = nrow(spontComp)
    Ncomp = ncol(spontComp)
    
    mescolors = colorRampPalette(c('red','magenta','gold','green','blue'))(Nneur)
    
    for(comp in 1:Ncomp)
        mygraph(spontComp[,comp], interacComp[,,comp], names[comp], neurnames, scale, monlayout, mask, mescolors)
}



                                        # somme des erreurs sur les fonctions d'interaction ?
                                        # renvoie une erreur sur la partie spontanee (somme totale des erreurs) et une erreur sur les interactions (c'est la somme totale des erreurs l1)
compute_errors <- function(S1, S2)
{
                                        # S1 et S2 sont deux listes a deux champs - contenant S (tableau Nneur) et I
                                        #v2 est une variable locale, une matrice qui pourrait etre utile
    Nneur = nrow(S1[[1]])
    Ncomp = ncol(S1[[1]])
    v1 = vector("numeric", length=Ncomp)
#    print(paste("in compute_errors", Nneur, Ncomp))
#    print(paste(length(S1), length(S2)))
#    print(dim(S1[[1]]))
#    print(dim(S1[[2]]))
#    print(dim(S2[[1]]))
#    print(dim(S2[[2]]))
#    flush.console()
    for(comp in seq_len(Ncomp))
    {
        v1[comp] = sum(abs(S1[[1]] - S2[[1]]))
    }

    v2 = array(0,dim=c(Nneur, Nneur, Ncomp))
    v3 = vector("numeric", length=Ncomp)
    for(comp in seq_len(Ncomp))
    {
        for(i in seq_len(Nneur))
        {
            for(j in seq_len(Nneur))
            {
                                        #                print(pw_minus(S1[[2]][i,j,comp][[1]], S2[[2]][i,j,comp][[1]] ))
                                        #               flush.console()
                v2[i,j,comp] = getl1norm(pw_minus(S1[[2]][i,j,comp][[1]], S2[[2]][i,j,comp][[1]] ))
            }
        }
        
        v3[comp] = sum(v2[,,comp])
    }
    return(list(v1,v3))
}


                                        # make the difference between two piecewise constant functions with different support. M1 and M2 are two-row matrices containing the support of the piecewise constant function on the first row and the values on the second one. We have
                                        #  M1 = ( 0 t1 t2 t3)
                                        #       ( g1 g2 g3 0)
                                        #
                                        # means      f = g1 if  0 <= t <= t1
                                        #            f = g2 if  t1 < t <= t2
                                        #            f = g3 if  t2 < t <= t3
                                        #            f = 0  if  t3 < t
                                        #
                                        #
pw_minus <- function(M1, M2, eps=1e-8)
{
                                        #    print(is(M1))
                                        #    print(length(M1))
                                        #    print(M1[[1]])
                                        #    print(dim(M1))
                                        #    print(length(M1))
                                        #    print(length(M2))
                                        #    flush.console()
    if(length(M2)==0)
        return(M1)
    if(length(M1)==0)
        return(rbind(M2[1,], -M2[2,]))
    stopifnot(nrow(M1)>=2)
    stopifnot(nrow(M2)>=2)
    tau1 = M1[1,]
    tau2 = M2[1,]
    gamma1 = M1[2,]
    gamma2 = M2[2,]
    
    tau = c(tau1, tau2)
    taus = unique(sort(tau))
    val1 = val2 = 0
    resu = c()
    for(t in taus)
    {
        zu = which(abs(tau1-t)<=eps)
        if(length(zu))
            val1 = gamma1[zu]
        zv = which(abs(tau2-t)<=eps)
        if(length(zv))
            val2 = gamma2[zv]
        resu = c(resu, val1-val2)
    }
    stopifnot(length(taus)==length(resu))
    return(matrix(rbind(taus, resu), nrow=2))
}

                                        # make the addition between two piecewise constant functions with different support. M1 and M2 are two-row matrices containing the support of the piecewise constant function on the first row and the values on the second one. We have
                                        #  M1 = ( 0 t1 t2 t3)
                                        #       ( g1 g2 g3 0)
                                        #
                                        # means      f = g1 if  0 <= t <= t1
                                        #            f = g2 if  t1 < t <= t2
                                        #            f = g3 if  t2 < t <= t3
                                        #            f = 0  if  t3 < t
                                        #
pw_plus <- function(M1, M2, eps=1e-8)
{
    tau1 = M1[1,]
    tau2 = M2[1,]
    gamma1 = M1[2,]
    gamma2 = M2[2,]
    stopifnot(nrow(M1)>=2)
    stopifnot(nrow(M2)>=2)

    tau = c(tau1, tau2)
    taus = unique(sort(tau))
    val1 = val2 = 0
    resu = c()
    for(t in taus)
    {
        zu = which(abs(tau1-t)<=eps)
        if(length(zu))
            val1 = gamma1[zu]
        zv = which(abs(tau2-t)<=eps)
        if(length(zv))
            val2 = gamma2[zv]
        resu = c(resu, val1+val2)
    }
    stopifnot(length(taus)==length(resu))
    return(matrix(rbind(taus, resu), nrow=2))
}

                                        # spontComp de taille Nneur-by-Ncomp
                                        # interacComp de taille Nneur-by-Nneur-by-Ncmp (fct theoriques)
                                        # Lasso$BL est une liste de taille Ncomp dont chaque element contient une matrice (1+k*Nneur)-by-Nneur
plotspont<-function(IS, colors, names=c(), tracelegend=c())
{
    yrange = c(Inf, -Inf)
    lpch = c(8, 5, 16, 1, 2, 7, 3, 6)
    N_traces = length(IS)
    stopifnot(N_traces <= length(lpch))
    if(length(tracelegend)==0) {
        tracelegend = c('exact', 'BL', 'BOL', 'lshoot')}
    
    stopifnot(N_traces <= length(tracelegend))
    for(i in seq_len(length(IS))) {
        yrange = c(min(yrange[1], min(IS[[i]]$S)), max(yrange[2], max(IS[[i]]$S)))
    }
    title = 'Spontaneous values'
    if(length(names))
        {png(filename = names[1])}
    for(i in seq_len(N_traces)) {
        plot(IS[[i]]$S, pch=lpch[i], col=colors[i], ylim=yrange, xlab='Neuron number', ylab='Spontaneous values', main=title)
        par(new=TRUE)
    }
                                        #    if(length(names))  {
    legend("topright", col=colors, cex=0.5, seg.len=.75, pch=lpch[1:N_traces], legend=tracelegend[1:N_traces], bty="n")
                                        #    }
        if(length(names)>0)
        {dev.off()}
                                        # 2nd plot - Error for each neuron
                                        #    dev.new()
                                        #    title = 'Error for spontaneous values'
                                        #    if(length(names))  {
                                        #        title = paste(title, 'between', names[1], 'and', names[2])
                                        #    }
                                        #    plot(abs(IS1$S-IS2$S), pch=8, ylim=c(0, max(abs(IS1$S-IS2$S))), main=title, xlab='Neuron number', ylab='Error')
}



                                        # spontComp de taille Nneur-by-Ncomp
                                        # interacComp de taille Nneur-by-Nneur-by-Ncmp (fct theoriques)
                                        # Lasso$BL est une liste de taille Ncomp dont chaque element contient une matrice (1+k*Nneur)-by-Nneur
plotspontold<-function(IS1, IS2, names=c())
{
    stopifnot((length(names)==0) || (length(names)==2))
                                        # 1st plot - commparison between spontaneous values
    yrange = c(min(min(IS1$S),min(IS2$S)), max(max(IS1$S),max(IS2$S)))
    plot(IS1$S, pch=8, col='red', ylim=yrange, xlab='Neuron number', ylab='Spontaneous values')
    par(new=TRUE)
    title = 'Spontaneous values'
    if(length(names))  {
        title = paste(title, 'for', names[1], 'and', names[2])
    }
    plot(IS2$S, pch=5, ylim=yrange, main=title, xlab='Neuron number', ylab='Spontaneous values')
    if(length(names))  {
        legend("topright", col=c("red","black"), pch=c(8,5), legend=c(names[1], names[2]), bty="n")
    }
                                        # 2nd plot - Error for each neuron
    dev.new()
    title = 'Error for spontaneous values'
    if(length(names))  {
        title = paste(title, 'between', names[1], 'and', names[2])
    }
    plot(abs(IS1$S-IS2$S), pch=8, ylim=c(0, max(abs(IS1$S-IS2$S))), main=title, xlab='Neuron number', ylab='Error')
}

get_n <- function(N)
{
                                        # n*n >= N > (n-1)**2
                                        #
    n = floor(sqrt(N))
    if(n*n==N) {
        return(c(n,n))
    }
    else {
        if(n*n >= N) {
            coeff1 = n}
        else{
                coeff1 = n+1
            }
        p = N%/%coeff1
        if(N == p*coeff1) {
            return(c(as.integer(coeff1),p) )}
        else  {
                return(c(as.integer(coeff1), p+1))}}

}
