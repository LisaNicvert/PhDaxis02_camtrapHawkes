                                        # to create interacComp array from a network file
                                        #
get_network <- function(Nneur, full_spec_file) {
    interacComp	= array(c(list()), c(Nneur,Nneur,1))
    network_dist = read.csv(full_spec_file, sep = ",", header=TRUE)
    spontComp = matrix(network_dist[seq(1,Nneur*Nneur,Nneur),1], nrow=Nneur)
#    print('---------------------------')
#    print('')
#    print(network_dist)
#    print('')
#    print('---------------------------')
    for(i in 1:dim(network_dist)[1]) {
        if(dim(network_dist)[2] >= 9) {
            for(j in seq.int(9,dim(network_dist)[2],2)) {
                network_dist[i, j] = network_dist[i, j] + network_dist[i, j-2]
            }
        }
    }
    max_nb_breakpoints_dist = ncol(network_dist)
    print(max_nb_breakpoints_dist)
                                        # Reading the data from a csv file, then formatting it to fit the functions need
# interacComp[a,b] is the interaction from a to b
    
    for(i in 0:(nrow(network_dist)-1)) {
#            interacComp[i%/%Nneur+1,i%%Nneur+1,1][[1]] = cbind(matrix(network_dist[i+1,6:(ncol(network_dist)-1)], nrow = 2), c(0.04,0))
            interacComp[i%/%Nneur+1,i%%Nneur+1,1][[1]] = matrix(network_dist[i+1,6:ncol(network_dist)], nrow = 2)
    }
    return(list(S=spontComp, I=interacComp))
}

#II = get_network(8, '/workdir/gscarella/INRIA_SED/nm-data/nm-reconstruction/8.csv')
#print('II$I[1,4,1][[1]]')
#print(II$I[1,4,1][[1]])
#print('II$I[1,6,1][[1]]')
#print(II$I[1,6,1][[1]])
#print('II$I[4,1,1][[1]]')
#print(II$I[4,1,1][[1]])
#print('II$I[6,1,1][[1]]')
#print(II$I[6,1,1][[1]])
