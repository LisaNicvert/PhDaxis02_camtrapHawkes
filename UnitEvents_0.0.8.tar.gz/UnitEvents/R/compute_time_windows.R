compute_time_windows <- function(a, b, duration, spacing)
{
    if(duration> (b-a)) {
        warning("Empty time window as duration>(b-a)")
        return(list(A=matrix(nrow=0,ncol=0), L=0, len=0))
    }
    if(spacing>duration) {
        warning("As spacing > duration, there is a gap between time windows")
    }
#        s <- seq(a, b-spacing, by=spacing)  # previous version
    epsilon <- 1.e-15
    s <- seq(a, b, by=spacing)  # 1d 
    A <- matrix(nrow=2, ncol=length(s))
    A[1,] <- s
    A[2,] <- s + duration
                                        #in the second raw of A, find values > b and remove corresponding columns
#    jok = which(A[2,]>b)
    jok = which( (A[2,]-b) >epsilon )
    
    if(length(jok)) {
#        print(jok)
        A = A[,seq_len(jok[1]-1)]
        if(jok[1]<=2) spacing = 0
    }
    A = as.matrix(A, nrow=2)
    return(list(A=A, L=spacing, len=ncol(A)))
}

##To define the time windows
#compute_windows <- function(F1,F2,Neur1,Neur2)
#{
#  m <- 0
#  n <- nrow(Neur1)
#  M <- max(Neur1[,ncol(Neur1)])+1
#  #  print(paste('1:n',as.character(n)))
#  for (i in 1:n)
#  {
#    a1 <- F1[i,-1]
#    a2 <- F2[i,-1]
#    x1 <- which(a1!=0)
#    x2 <- which(a2!=0)
#    if (length(x1)!=0)
#    {
#      if (length(x2)!=0)
#      {
#        m <- max(m,Neur1[i,2],Neur2[i,2])
#        M <- min(M,Neur1[i,ncol(Neur1)],Neur2[i,ncol(Neur2)])  
#      }
#    }
#  }
#  if (m==0)
#    m <- 0.001
#  
#  print("")
#  print("Min-max window values are ")
#  cat("m=",m,", ")
#  cat("M=",M,"\n")
#  #compute_windows=seq(m,M,0.001)
#  return(seq(m,abs(M-0.1),0.001))
#}
