                                        #source('lassoshooting.R')

compute_BOL <- function(GbVB, BL)
    {
        Ncomp = length(BL)
	Nneur = ncol(BL[[1]])
        BOL = lapply(seq_len(Ncomp), FUN=function(comp)
    {
        sapply(1:Nneur, FUN=function(nneur)
        {
            poscoeff = which(abs(BL[[comp]][,nneur])>0) # determination of the support
            a_BO = 0*as.matrix(BL[[comp]][,nneur])
            if (length(poscoeff)!=0)
            {
                Gpos = GbVB$G[[comp]][poscoeff,poscoeff] # G restricted to the support
                a_BO[poscoeff] = solve(Gpos)%*%as.matrix(GbVB$mu1[[comp]][poscoeff,nneur]) #inversion ie OLS solution on the support
            }
            return(a_BO)
        })
    })
        return(BOL)
    }

compute_BVL <- function(GbVB, k, del, Z, BOL)
    {
        Ncomp = length(BOL)
	Nneur = ncol(BOL[[1]])
	print("NNeur dans compute_BVL")
	print(Nneur)
flush.console()
        mat1 = matrix(1, nrow=Nneur, ncol=Nneur) - diag(rep(1,Nneur))
	BVL = lapply(seq_len(Ncomp), FUN=function(comp)
                    {
                        mint = matrix(0, nrow=Nneur, ncol=Nneur)
                        for(nneur2 in 1:Nneur)
                            {
                                
                                mint[,nneur2] = colSums(BOL[[comp]][(k*(nneur2-1)+2):(k*nneur2+1),]*del)
                                
                            }
                                        # mint_Inter[i,j] = sum of all the elements of mint_Inter[,j] - mint_Inter[i,j]
                        mint_Inter = mat1*mint
                        
                        indice = which(mint_Inter>0)
                        if(length(indice)>0)
                            {
                                exc = mint_Inter[indice]
                                exc_sort = sort(exc)
                                exc_sortbis = c(0, exc_sort)
                                saut = diff(exc_sortbis)
                                indlim = min(which(saut>Z*max(saut))) # Z only used here
                                
                                if(indlim>1)
                                    {
                                        threshold = exc_sort[indlim-1]
                                        
                                    }else{threshold = 0}
                            }else{threshold = 0}
                        
                        adj_mat = 1*(mint>threshold)+1*(mint<0)
                        
                        res = BOL[[comp]]
                        for(nneur2 in 1: Nneur)
                            {
                                res[(k*(nneur2-1)+2):(k*nneur2+1),] = res[(k*(nneur2-1)+2):(k*nneur2+1),]%*%diag(adj_mat[,nneur2])
                            }
                        
                        return(res)
                    })
        return(BVL)
    }

BoxLassoV2 <- function(GbVB, del, k, gamma, Z, methods="all")
{
                                        # init
    BL = BOL = BVL = c()
    eltimes = list()
    method_list = c("neurocorr")
    if((length(methods)==1) && (tolower(methods)=="all"))
        {
            methods = method_list
        }
    Ncomp = length(GbVB$mu1)
    Nneur = ncol(GbVB$mu1[[1]])
                                        # end of init
    
    if(is.element("neurocorr", tolower(methods)))  {
        t1 = proc.time()
        BL = lapply(seq_len(Ncomp), FUN=function(comp)
            {
                coeff = NeuroCorr_Coeff(GbVB$G[[comp]], GbVB$mu1[[comp]], GbVB$mu2[[comp]], GbVB$muA[[comp]], gamma)
                return(coeff$a)
            })
        eltimes["BL"] = (proc.time()-t1)[3]
        
        t1 = proc.time()
        BOL = compute_BOL(GbVB, BL)
        eltimes["BOL"] = eltimes[["BL"]] + (proc.time()-t1)[3]
                                        # mat1 = 1 except on the diagonal (0)
        t1 = proc.time()
        
#        if(Nneur>1)
#            {
#                t1 = proc.time()
#                BVL = compute_BVL(GbVB, k, del, Z, BL)
#                eltimes["BVL"] = eltimes[["BOL"]]+(proc.time()-t1)[3]
#            }
    }


    					BVL=BOL
if(Nneur>1)
        {
            return(list(BL=BL, BOL=BOL, BVL=BVL, times=eltimes))
        }else{
            return(list(BL=BL, BOL=BOL, times=eltimes))  #Nneur = 1
        }
}
