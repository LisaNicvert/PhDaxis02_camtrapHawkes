dll_load <-function(winkpath='.', name='wink')
{
    ## build the DLL name
    wink_dll <- paste(winkpath,.Platform$file.sep, name, .Platform$dynlib.ext, sep="")
                                        #print(wink_dll)
    message(paste("LOADING", wink_dll) )

    ## load the dll only once
    if(name=='neurocorr') name = 'NeuroCorr'
    nameVersion = c(paste(name, '_version', sep=''), paste(name, '_Version', sep=''))
    if( is.loaded(nameVersion[[1]]) || is.loaded(nameVersion[[2]])) dyn.unload(wink_dll)
    dyn.load(wink_dll)
#    if( !is.loaded(name) ) stop(paste("Unable to find", name), call.=TRUE)
    if( !is.loaded(nameVersion[[1]]) && !is.loaded(nameVersion[[2]])) warning(paste("Unable to find", wink_dll), call.=TRUE)
    
                                        #test pour sourcer le wink.R initial - c'est inutile car ca plante a dyn.load ou dyn.unload
                                        #source(paste(winkpath,.Platform$file.sep,"wink.R",sep=""))
                                        #wink_xts_dll <- paste("wink_xts",.Platform$dynlib.ext, sep="");
                                        #if( is.loaded("wink_xts") ) dyn.unload(wink_xts_dll);
                                        #dyn.load(wink_xts_dll);
}
