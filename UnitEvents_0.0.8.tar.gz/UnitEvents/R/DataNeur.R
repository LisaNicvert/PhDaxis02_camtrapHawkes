                                        #DNeur function
#DNeur <- function(linput=list("Neur1_c13.txt","Neur2_c13.txt"), DName="", listOptions=list(), DNVersion="matrix")
DNeur <- function(linput=list("Neur1_c13.txt","Neur2_c13.txt"), DName="", listOptions=list())
{
	if(is.matrix(linput) || is.character(linput)) linput = list(linput)
        if( !is.list(linput)) stop('Input argument should be a list', call.=TRUE)

        len = length(linput)
        withFiles = FALSE

#        if(DNVersion == "matrix")
        pFile <- function(inputFile) {DNeurFile.matrix(inputFile, listOptions)}

        if(length(which(lapply(linput, is.character)==TRUE))== len)
            {
# linput = liste de noms de fichiers
                D = lapply(linput, pFile)
                withFiles = TRUE
            }
            
#        if(DNVersion == "matrix")
            pMatrix <- function(inputM) {DNeurMatrix.matrix(inputM, listOptions)}

        if(length(which(lapply(linput, is.matrix)==TRUE))== len & !withFiles)
            {
                D = lapply(linput, pMatrix)
            }
        else if (!withFiles)
            {
#            print('BUMP!!!!')
#            print(            lapply(linput, is.matrix))
                stop("Wrong linput argument in DNeur", call.=TRUE)
            }

#        if(DNVersion == "matrix")
#        {
        vcol = sapply(D, ncol)
        #to fill with zeros
        h<-function(M) { cbind(as.matrix(M), matrix(0,nrow=nrow(M),ncol=max(vcol)-ncol(M)))}
        D = lapply(D, h)
#        print('length D- 0')
#        print(is(D))
#        print('length D')
#        print(length(D))        
#        print(max(vcol))        
        D = Reduce(rbind, D)
        return(D)
    }


                                        #creation of a DataNeur from a file
DNeurFile.matrix <- function(neurfile, listOptions=list())
{
#    if( !is.character(neurfile) ) stop("neurfile should be a string", call.=TRUE);
                                        #reading of input arguments
    fname <- check_input(neurfile)

    M <- as.matrix(read.table(fname))

    M <- use_options(M, listOptions)

    M <- counting_spikes(M)
    return(M)
}

                                        #creation of a DataNeur from a matrix
DNeurMatrix.matrix <- function(M, listOptions=list())
{
    if( !is.numeric(M) ) stop("M should be numeric", call.=TRUE);
                                        #reading of input arguments
    M <- use_options(M, listOptions)

    M <- counting_spikes(M)
    return(M)
}


data_treatment <- function(neufiles)
{
  if( !is.list(neufiles)) stop("neufiles should be a list", call.=TRUE);
    Datatemp1 <- read.table(neufiles[[1]])
#    load(neufiles[[1]])
                                        #  print("neufiles2")
  #  print(neufiles[[2]])
  Datatemp2 <- read.table(neufiles[[2]])
#    load(system.file(neufiles[[2]]))
#   load(neufiles[[2]])
    ntrials <- nrow(Datatemp1)
  #  print(paste('ntrials=',as.character(ntrials)))
  Data1 <- matrix(0,ncol=ncol(Datatemp1)+1,nrow=ntrials)
  Data2 <- matrix(0,ncol=ncol(Datatemp2)+1,nrow=ntrials)
  Datatemp1b <- Datatemp1[,-c(1,((ncol(Datatemp1)-6) :ncol(Datatemp1)))]			#pour compter le nombre de spikes, on retire tout ce qui concerne les temps de signaux soit la premiere colonne et les 7 dernieres
  Datatemp2b <- Datatemp2[,-c(1,((ncol(Datatemp2)-6) :ncol(Datatemp2)))]			#pour compter le nombre de spikes, on retire tout ce qui concerne les temps de signaux soit la premiere colonne et les 7 dernieres
  AA1 <- (Datatemp1b!=0)
  AA2 <- (Datatemp2b!=0)
  N1 <- apply(AA1,1,sum)
  N2=apply(AA2,1,sum)
  Data1[,1] <- N1												#premiere colonne de Data est le nombre de spikes
  Data2[,1] <- N2
  Data1[,2:ncol(Data1)] <- as.matrix(Datatemp1)/10000						#remise des temps en secondes
  Data2[,2:ncol(Data2)] <- as.matrix(Datatemp2)/10000
  ncol1 <- ncol(Data1)
  ncol2 <- ncol(Data2)
  Neur1 <- Data1
  Neur2 <- Data2
  F1 <- Neur1[,-c(2,(ncol1-6):ncol1)]
  F2 <- Neur2[,-c(2,(ncol2-6):ncol2)]
  #  print(typeof(F1))
  stopifnot(nrow(F1)==nrow(Neur1))
  ## Test
  return(list(ntrials=ntrials, N1=F1, N2=F2))
                                        #  return(list(ntrials=ntrials, DataNeur =list(F1,F2), Neur=list(Neur1,Neur2))

     }

#creation of a DataNeur for a Homogeneous Poisson Process (global)
spikes.Poisson <- function(nneurons, lambda, a, b, ntrials)
{
    if(length(lambda)==1) lambda = rep(lambda, nneurons)
    stopifnot(length(lambda)>= nneurons)
    inject<-function(i) { spikes.Poisson.single(lambda[i], a, b, ntrials)}
    D = lapply(1:nneurons, inject)
    D = Reduce(rbindfill, D)
    return(D)
}

                                        #creation of a DataNeur for a Homogeneous Poisson Process (for one neuron)
spikes.Poisson.single <- function(lambda, a, b, ntrials)
    {
        p = lambda*(b-a)
        ntops <- rpois(ntrials, p)
        M <- matrix(data=0, nrow=ntrials, ncol=max(ntops)+1)
        M[,1] <- ntops
#        if(length(which(ntops==0)))
#            warning("Number of spikes =0 !")

        for (i in 1:ntrials)		# for each trial
        {
            r <- ntops[i]	# depending on ntops
            if (r!=0)
            {	x <- runif(r,a,b)		# uniform law
                M[i,2:(r+1)] <- sort(x)	# sorting
            }
            else			
                warning(paste("Number of spikes = 0 for trial",i,"!"))
        }
#        F1 <- M[1:ntrials,]
#        F2 <- M[(ntrials+1):(2*ntrials),]
#        return(list(DN=list(F1,F2), name=name, xrange=c(0,max(M[,-1])), ntrials=nrow(F1) ) )
        return(M)
    }


#creation of a DataNeur
spikes.inject<-function(nneurons, lambda, a, b, ntrials, lambdainject, jitter=0)
{
  inject <- spikes.Poisson.single(lambdainject, a, b, ntrials)
  if(length(lambda)==1) lambda = rep(lambda, nneurons)
  stopifnot(length(lambda)>= nneurons)
  neur <- function(i) { dmerge(spikes.Poisson.single(lambda[i], a, b, ntrials), inject, jitter, a, b)}
  D1 = lapply(1:nneurons, neur)
  D = Reduce(rbindfill, D1)
  
  return(D)
}



                                        #to compute a maximum time value of a DataNeur given by an input file. Here the maximum is in the last column of the neuron data files (in seconds). Specific to Neur1_c13.txt file!
maxtime <- function(NeuDataFiles)
{
  Datatemp1 <- read.table(NeuDataFiles[[1]])
  Datatemp2 <- read.table(NeuDataFiles[[2]])
#  time_max <- max(c(Datatemp1[,ncol(Datatemp1)], Datatemp2[,ncol(Datatemp2)]))/10000
# The minimum value (in seconds) in the last column
  time_max <- min(c(Datatemp1[,ncol(Datatemp1)], Datatemp2[,ncol(Datatemp2)]))/10000
}



                                        #to compute minimum and maximum time values of a DataNeur matrix which is assumed to be ordered (except 1st column)
minmaxtimes <- function(M)
{
#    print(is(M))
    stopifnot(is.matrix(M))
    g<-function(u) { return( c(u[2],u[u[1]+1])) }
    t <- t(apply(M, 1, g))
    tmax <- max(t[,2])
    tmin <- min(t[,1])

    return(c(tmin,tmax))
}


use_options <- function(M, listOptions=list())
{

    if(length(which(names(listOptions)=='removeCols')))
    {
        if(is.numeric(listOptions$removeCols))
            {
                lcol <- listOptions$removeCols
                stopifnot(max(lcol)<=ncol(M))
                M <- M[,-c(lcol)]
            }

        if(is.function(listOptions$removeCols))
            {
                fcol <- listOptions$removeCols
                M <- t(apply(M, 1, fcol))  #
            }
    }

    if(length(which(names(listOptions)=='removeRows')))
    {
        if(is.numeric(listOptions$removeRows))
            {
                lrows <- listOptions$removeRows
                stopifnot(max(lrows)<=nrow(M))
                M <- M[-c(lrows),]
            }

        if(is.function(listOptions$removeRows))
            {
                frows <- listOptions$removeRows
                M <- apply(t(M), 2, fcol) 
            }
    }

    if(length(which(names(listOptions)=='scaling')))
    {
        stopifnot(is.numeric(listOptions$scaling))
        scal <- listOptions$scaling
        M <- M*scal
    }

    if(length(which(names(listOptions)=='shift')))
    {
        stopifnot(is.numeric(listOptions$shift))
        shift <- listOptions$shift
        M <- M + shift
    }

    
    return(M)
}

                                        # To add an additional first column to a DataNeur as the number of spikes per trial
                                        #
counting_spikes<- function(M)
{
    epsilon = 1e-6  #for numerical precision; if abs(v)<epsilon, then  v=0
                                        #    print(is(M))
    if( !is.matrix(M)) stop("M should be a matrix", call.=TRUE);
    M <- cbind(rep(NA, nrow(M)), M)
    A <- (abs(M[,-1])>epsilon)
    c1 <- apply(as.matrix(A), 1, sum)
    M[,1] <- c1
    return(M)
}

                                        #own rbind
                                        #rbind and fill missing columns with 0
rbindfill <- function(a, b)
{
  m = max(ncol(a),ncol(b))
  if(ncol(a)<m)
  {
    a = cbind(a, matrix(0,nrow=nrow(a), ncol=(m-ncol(a))))
  }
  if(ncol(b)<m)
  {
    b = cbind(b, matrix(0,nrow=nrow(b), ncol=(m-ncol(b))))
  }
  return(rbind(a,b))
}

#Merge for DataNeur
dmerge <- function(N, inject, jitter, a, b)
{
  ncolM = max(N[,1]+inject[,1])+1
  M = matrix(data=0, nrow=nrow(N), ncol=ncolM)
  M[,1] = N[,1] + inject[,1]
  for(i in 1:nrow(M))
  {
    A = N[i,2:(N[i,1]+1)]
    B = inject[i,2:(inject[i,1]+1)]
    C = runif(inject[i,1], pmax(B-jitter,a), pmin(B+jitter,b))
    spike = sort(c(A,C))
    M[i,2:(M[i,1]+1)] = spike
  }
  return(M)
  }
  

