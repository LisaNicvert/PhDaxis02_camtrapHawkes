#To check if neuron file names of UnitEvents function exist
# Returns the names of neuron files
                                        # If the first file doesn't exist, default file is chosen
#
check_input <- function(neurfile)
{
  #  if(!file.exists(neurfile)|!file.exists(neur2file)){
  if(!file.exists(neurfile)){
    print('Missing file. Default file Neur1_c13.txt is chosen')
    zz <- "Neur1_c13.txt"
  } else
      zz <- neurfile
  
  stopifnot( file.exists(zz))
  print("")
  print(paste('The neuron file is',zz))
#  titlename <- "" # a reprendre (elenver suffixe par exemple) 
  #  print(titlename)
  # Fin nom pour figure en sortie
#  return(list(ndf=zz, titlename=titlename))
  return(zz)
}

##-----------------------------------------
##load_neurostatpath To load neuro-stat code functions
##------------------------------------------
#
load_neurostatpath <- function(neurostatpath=paste(specificpath(),'UnitEvents','neuro-stat',sep='/'))
{
  # To get the right path for neuro-stat code (default value has been taken into account)
#    source('wink_load.R')
    rpath <- get_nspath(neurostatpath)
##    print('inside load_neurostatpath')
#    print(paste('neuro-stat code is under', rpath)) 
                                        # on modifie wink.R dans neuro-stat (au niveau du path), l'appel a wink_load est inutile
    source(paste(rpath,"/v3/src/wink_mam4/wink.R",sep=''))
    wink_load(paste(rpath,"/v3/src/wink_mam4/",sep=''))
                                        #    source(paste(rpath,"/wink.R",sep=''))
                                        #  wink_load(paste(rpath,'/v3/src/wink_mam4',sep=''))

#dyn.load( paste(.libPaths()[[1]], 'UnitEvents/neuro-stat/neurocorr/v4/neurocorr.so', sep='/') )
#source( paste(.libPaths()[[1]], 'UnitEvents/neuro-stat/neurocorr/v4/neurocorr.R', sep='/') ) 
    dll_load(winkpath=paste(rpath,"/neurocorr/v4/",sep=''), name='neurocorr')
    source(paste(rpath,"/neurocorr/v4/neurocorr.R",sep=''))
}

##-----------------------------------------
##get_nspath To get the path of neuro-stat code
##------------------------------------------
#
get_nspath <- function(neurostatpath=paste(specificpath(), 'UnitEvents', 'neuro-stat', sep='/'))
{
  print("")
                                        # reference path. For ex: ~/R/x86_64-pc-linux-gnu-library/3.2/UnitEvents/neuro-stat/
    ref_path = paste(specificpath(), 'UnitEvents', 'neuro-stat', sep='/') 

  if (nchar(neurostatpath)>0){
    neurodirok <- ns.check(neurostatpath)

    if(!neurodirok)
    {
      print('The value of neurostatpath seems to be uncorrect. No neuro-stat existing directory')
      
      if(!ns.check(ref_path)) {
      ns.clone(ref_path)
      ns.compile(ref_path)
      }
                                        #      rpath <- paste(getwd(),'/neuro-stat',sep='')
    rpath <- ref_path
    }
    else
        rpath <- neurostatpath
  }
  else  #empty
  {
      neurodirok <- ns.check(ref_path)
#    if(neurodirok)
#      print(paste('neuro-stat code already exists in', ref_path,'directory'))
      if(!neurodirok)
      {
        ns.clone(ref_path)
        ns.compile(ref_path)
    }
    rpath <- ref_path
  }
  return(rpath)
}



ns.clone <- function(destdir)
{
##        print('No path for neuro-stat. Cloning it from git.math.cnrs.fr - it can take a few minutes ...')
#        print('No path for neuro-stat. Cloning it from sourcesup.renater.fr - it can take a few minutes ...')
#        print('')
#      #          system('git clone --quiet https://github.com/ybouret/neuro-stat')
#      #	 system('git clone --quiet https://git.math.cnrs.fr/forge/neuro-stat')
#      #system('git clone --quiet https://git.math.cnrs.fr/forge/neuro-stat')
#      system('rm -fr neuro-stat')
###      system('git clone --quiet git@git.math.cnrs.fr:forge/neuro-stat')
###      system('git clone --quiet https://daemon@git.math.cnrs.fr:/anon/forge/neuro-stat')
###        system('git clone --quiet https://daemon@git.math.cnrs.fr:/anon/forge/neuro-stat')
##        system('git clone git://git.renater.fr/neuro-stat-ljad.git neuro-stat')
#        system('git clone https://git.renater.fr/neuro-stat-ljad.git neuro-stat')
    system(paste('rm -fr',destdir))
    print('No path for neuro-stat. Cloning it from sourcesup.renater.fr - it can take a few minutes ...')
    print('')
#    system(paste('git clone https://git.renater.fr/neuro-stat-ljad.git', destdir))
    system(paste('git clone -b timing https://git.renater.fr/anonscm/git/neuro-stat-ljad/neuro-stat-ljad.git', destdir))
    print(paste('neuro-stat code installed in directory',destdir))
}

ns.compile  <- function(destdir)
{
#                                        #      print(paste('cd ',getwd(),'/neuro-stat/neurocorr;make update VERBOSE=0;cd v4;make VERBOSE=0',sep=''))
#      system(paste('cd ',getwd(),'/neuro-stat/neurocorr;make update -s;cd v4;make -s;cd ../../v3/src/wink_mam4/;make -s',sep=''))

    if(!file.exists(destdir)) stop(paste('No directory',destdir), call.=TRUE)
    system(paste('cd ', paste(destdir,'neurocorr',sep='/'), ';make update -s;cd v4;make -s;cd ../../v3/src/wink_mam4/;make -s',sep=''))
}

ns.check <- function(neurostatpath)
{
#    neurodirok <- file.exists(neurostatpath) & file.exists(paste(neurostatpath,'/wink.R',sep='')) & file.exists(paste(neurostatpath,'/wink.so',sep=''))
    neurodirok <- file.exists(neurostatpath) & file.exists(paste(neurostatpath,'/v3/src/wink_mam4/wink.R',sep='')) & file.exists(paste(neurostatpath,'/v3/src/wink_mam4/wink.so',sep=''))
    return(neurodirok)
}

specificpath <- function()
{
    if(isLinux())
    {
#        g1<-function(u) { v = gregexpr(getUserName(),u)[[1]]; attributes(v)=NULL; return(v);}
#        V1 = sapply(.libPaths(), g1)  #vector
#        W = which(V1>-1)
#        return(.libPaths()[W[[1]]])
        return(Sys.getenv('R_LIBS_USER'))
    }
    if(isMac())
        return(.libPaths()[[1]])
    else
        stop('Wrong OS', call.=TRUE)
}

isMac <- function()
getOS() == "Darwin"

isLinux <- function()
getOS() == "Linux"

isWindows <- function()
    getOS() == "Windows"

getUserName <- function()
return(Sys.info()[7][[1]])

getOS <- function()
return(Sys.info()[1][[1]])    
