                                        # Benjamin-Hochberg procedure
                                        # p is the array of input probabilities
                                        #
                                        # BH(0.05,c(0.008,0.036,0.046)) returns 3 values
                                        # BH(0.05,c(0.008,0.036,0.06)) returns 1 value
                                        #
BH<-function(alpha=5e-2, p=runif(10), plot=FALSE)
{
                                        # For debugging
                                        #    fp = file("pvalues.txt", "w")
                                        #    cat(p, file=fp)
                                        #

    ps = sort(p, index.return=TRUE)
    K = length(p)
    Ind = ps$ix
                                        #print(alpha)
    if(plot) par(new=FALSE)

    idv = t(1:K)  #identity vector
    V = K*ps$x/idv

    U = which(V<=alpha)
    if (length(U)) indU = min(which(max(U)==U)) else indU = 0  # index of the maximum
    if(length(U)) indx = Ind[1:max(U)]  else indx = NULL

                                        # for plotting
    if(plot){
        indP = min(K, max(floor(1.2*indU), indU+3))  # index for graphical representation ( <= K)
        plot(idv[1:indP], ps$x[1:indP], pch=16, xlim=c(1,indP), ylim=c(0,2*ps$x[indP]), col='green', xlab="index", ylab="sorted p-values")
        col = 'red' #c('red', 'black', 'cyan', 'yellow', 'magenta')
        #j = 1
        par(new=TRUE)
                                        #        plot(idv, alpha*idv/K, pch=1, col=col[j], xlim=c(1,indP), ylim=c(0,2*ps$x[indP]), xlab="index", ylab="sorted p-values", type="b")
        plot(idv, alpha*idv/K, pch=1, col=col, xlim=c(1,indP), ylim=c(0,2*ps$x[indP]), xlab="index", ylab="sorted p-values", type="b")
                                        #j = j+1
#        legend("top", legend=c("p-values", paste("line y=", as.character(valpha), "*x/",as.character(K), sep='')), pch=c(16, rep(1,length(valpha))), col=c('green',col[1:length(valpha)]), cex=0.8)
        legend("top", legend=c("p-values", paste("line y=", as.character(alpha), "*x/",as.character(K), sep='')), pch=c(16, 1), col=c('green',col), cex=0.8)
        par(new=FALSE)
    }
                                        #    for (i in valpha)
                                        #        print(paste("Index returned by Benjamini-Hochberg procedure for alpha =",as.character(alpha[i]),"is",as.character(resu[i])))

                                        #                                        # For debugging
                                        #print('ALPHA !!!!')
                                        #    print(alpha)
                                        #    print(length(alpha))
                                        #    if(length(alpha)==1)
                                        #        {
                                        #            cat('\n', file=fp)
                                        #            cat(p[unlist(indx)], file=fp)
                                        #            cat('\n', file=fp)
                                        #            cat(unlist(indx), file=fp)
                                        #            close(fp)
                                        #        }
                                        #                                        #

    return(indx)
}

#Output of BH test
MulTestsBH <- function(DataNeur, A, delay, level, Rtest="all", iperm=FALSE, B=10000, num_threads=1, statistical_value='H', neurostatpath='')
{
#    print(c(level, delay, Rtest, iperm))
    if( !is.matrix(A) ) stop("A should be a matrix (time window matrix)", call.=TRUE);
    if ((Rtest=="symetric") || (Rtest=="symmetric") ) {
        print("Symmetric test with neuro-stat code")
        Rtest="symmetric"
    }
    else
        {
            if(Rtest=="all")
	    	    print("Rtest='all' -> Both upper and lower tests")
            else
                print(paste(Rtest, "test with neuro-stat code"))
        }

                                        #  A1 <- matrix(data=0,ncol=length(s),nrow=2)
                                        #  A1[1,] <- s
                                        #  A1[2,] <- s+0.1

      BH1 <- BHbN(A, level, delay, DataNeur, Rtest=Rtest, neurostatpath, iperm=iperm, B=B, num_threads=num_threads, statistical_value=statistical_value)
#    #    print(F1[1:3,1:6])
                                        #  
                                        #  print(typeof(F1))
                                        #  print(dim(F1))
                                        #  #print(length(BH1[[1]]))
                                        #  #print(dim(BH1[[2]]))
    output <- BH1[[2]]
#    print('Dimension de sortie')
#    print(dim(output))
                                        #  st <- (output[3,]==1)
    TWdetect <- which(output[3,]!=0)
#    print(dim(A))
    if(length(TWdetect)==0) {
        warning('In MulTestsBH: TWdetect empty!')
        return(list(matrix(nrow=3, ncol=0), BH1$pvalue, BH1$M))
                                        #  return(A[1:2, TWdetect])
    }
        if(length(TWdetect)>0) return(list(as.matrix(output[1:3,TWdetect]), BH1$pvalue, BH1$M))
}

##-----------------------------------------
##BHbN calls wink_coincmat
##------------------------------------------
#
BHbN <- function(TW, level, delay, DataNeur, Rtest, neurostatpath, iperm=FALSE, B=10000, num_threads=1, statistical_value="H")
{
                                        #    load_neurostatpath(neurostatpath)
    sN1 = DataNeur[1:(nrow(DataNeur)/2),]
    sN2 = DataNeur[(nrow(DataNeur)/2+1):nrow(DataNeur),]

                                        #    stopifnot(is.matrix(ssimul1))
    f1<-function(u) { if ((u%%2)==0) return(u/2) else return((u+1)/2);}
#    print(paste('delay - BHbN',as.character(delay)))
#    print(paste('level - BHbN',as.character(level)))
#    print(paste('Rtest - BHbN',as.character(Rtest)))
#    print(paste('neurostatpath - BHbN',as.character(neurostatpath)))
#    print(paste('iperm - BHbN',iperm))
    ntrials <- nrow(sN1)
    if(nrow(DataNeur)==2)
        {
            ntrials = 1
            sN1 = t(as.matrix(sN1))
            sN2 = t(as.matrix(sN2))
        }
    nw <- ncol(TW)                                        # number of time windows
    pval <- c()                                           # array of p-values
    ptest <- c()                                          # associated to the statistic test
    output <- matrix(data=0, ncol=nw, nrow=3)             # output time window matrix, the third row contains the result of the test
    output[1:2,] <- TW
                                        #the GAUE symmetric test is performed on each small time window [a,b] defined in TW
#    rm(Mc)  
    if(! iperm)
    {
        
        for (i in 1:nw)	
        {
            a = TW[1,i]
            b = TW[2,i]

            Mc = wink_coincmat(sN1, sN2, a, b, delay)			
                                        #print('length(Mc)')
                                        #print(length(Mc))
            Mc = matrix(Mc, ncol=ntrials)
                                        #    print(length(Mc[1]))
            C = matrix(ncol=1, nrow=3)
            C[1] = sum(diag(Mc))/ntrials # mean (over the trials) of the coincidence count
            C[2] = lambdaChapeau(a, b, sN1) # estimator of the firing rate of the 1st neuron
            C[3] = lambdaChapeau(a, b, sN2) # estimator of the firing rate of the 2nd neuron
            test = compute_pvalues(C, ntrials, a, b, delay, test=Rtest)

            pval <- c(pval, test[[1]])
            ptest <- c(ptest, test[[2]])
# if(i==nw)   print(pval); end

#            stopifnot(length(which(test[[2]]<0))>0)
        }
    }
    else  #with permutation
    {
        Mc = wink_permutation_pvalues("T", sN1, sN2, TW, delay, B, num_threads)		#Mc - 	2 lignes, TW$len col
        pval = matrix(Mc, ncol=1)
        ptest <- rep(c(-1,1), ncol(TW))
#        print(c(nrow(Mc),ncol(Mc)))
        if (Rtest=="upper")
            {
                pval = pval[seq(2,length(pval),2)]
                ptest = rep(1, length(pval))
            }
                if (Rtest=="lower")
            {
                pval = pval[seq(1,length(pval),2)]
                ptest = rep(-1, length(pval))
            }
    }
    
#    print('pval')
#    print(pval)
    idxpvalord = BH(alpha = level, p = pval)
    pos = unlist(idxpvalord)
    k = length(pos)
    ptestord = ptest[pos]
# print(k)
    
                                        #    print(pos)
#    print(ptestord)
#    stopifnot(length(idxpvalord)>0)
    if(k>0)
    {
#        pos = pos[1:k]  ## for permutation there are 2 p-values (pplus and pminus)
        if(iperm || (Rtest=="all"))
        {
            pos2 = sapply(pos, f1)
#            print('avt pos2')
#            print(pos2)
        }
        else
            pos2 = pos
###        output[3, pos2] = rep(1, length(pos2))
##        print('avt sortie3')
##        print(length(ptestord))
##        print(ptestord[1:k])
##        print(pvalordd$ix[1:k])
##        print(dim(output))
 #       if(iperm || (Rtest=="all"))
       if(Rtest=="all" || Rtest=="symmetric")
           output[3, sapply(pos, f1)] = rep(1, k) -2*(ptestord[1:k]<0)
        else
            output[3, pos2] = rep(1, length(pos2)) -2*(ptestord[1:k]<0)
#            print('ap sortie3')
    }
    else
        print('k==0')
                                        #    BHbN = list(ndw = k, prange = output, pvalue = pval, test = valeurtest)
    BHbN = list(ndw = k, prange = output, pvalue = pval, M=Mc)
                                        #    lNa=which(pval=='NaN')							
                                        #  
                                        #  llNa=length(lNa)
                                        #  
                                        #  if (llNa==0)
                                        #  {
                                        #    pvalordd=sort(pval,index.return=TRUE)
                                        #    pvalord=pvalordd$x
                                        #  }
                                        #  else
                                        #  {
                                        #    qqq=max(max(pval[-lNa]),q*1.001)
                                        #    pval[lNa]=rep(qqq,llNa)
                                        #    pvalordd=sort(pval,index.return=TRUE)
                                        #    pvalord=pvalordd$x
                                        #  }
                                        #  
                                        #  j=nw
                                        #  
                                        #  while (pvalord[j]>j*q/nw )
                                        #  {
                                        #    j=j-1									
                                        #    if (j==0){break}
                                        #  }
                                        #  #    print(c(max(s),min(s),length(s)))
                                        #  #    print(paste('La valeur limite de BHB est ',as.character(j),' alors que nw=',as.character(nw),sep=''))
                                        #  nw=j
                                        #  if (nw==0)
                                        #  {
                                        #    BHbN = list(nbreplage=0,plage=output,pvaleur=pval)
                                        #  }
                                        #  else
                                        #  {
                                        #    pos=pvalordd$ix[1:nw]
                                        #    output[3,pos]=rep(1,length(pos))
                                        #    #    output[3,pos]=output[3,pos]-2*(valeurtest[pos]<0)
                                        #    #        print((valeurtest[pos]<0)+1)
                                        #    BHbN = list(m=nw,plage=output,pvaleur=pval)
                                        #  }														
}
