# To compute statistical dependency tests on two neurons
# neurostatpath is a string which defines the path of neuro-stat code
# neur1file is the file containing spikes for the first neuron. Default file is Neur1_c13.txt (non-accessible content)
# neur2file is the file containing spikes for the second neuron. Default file is '' (as the file name automatically deduced from neur1file)
# delay (double) is the value used in coincidence detection. Default is 0.005
# level (double) is the value used in p-value computation. Default is 0.05
# rasterPlot (logical) To plot figures if true. Default value is TRUE.
# export (logical) To export the figures to png format. Default value is TRUE.
#
#
#UnitEvents <- function(Rcode="prog_amelfranck.R", neurostatpath="", neur1file="Neur1_c13.txt", neur2file="", delay=0.005, level=0.05, rasterPlot=TRUE, export=FALSE, Rtest="symmetric", TW=compute_time_windows(a=1e-3, b=2, dt=1e-3, enable_overlap=TRUE, overlap=2e-3))

#source('compute_time_windows.R')

#TW=compute_time_windows(a=1e-3, b=2.1, 1e-1, 0.05)
UnitEvents <- function(DataNeur, TW, delay=0.02, level=0.05, Rtest="all", iperm=FALSE, B=10000, num_threads=1, statistical_value="T", DName="Neuron", rasterPlot=TRUE, export=FALSE, neurostatpath="")
{
                                        #    rm(list=ls())
#  graphics.off()
#  library(stringr)
  if( !is.double(delay)) stop("delay should be a real", call.=TRUE)
  if( !is.double(level)) stop("level should be a real", call.=TRUE)
  if( !is.character(neurostatpath) ) stop("neurostatpath should be a string", call.=TRUE)
  if( !match(Rtest, c('upper','lower', 'all', 'symmetric', 'symetric'), 'nomatch'=FALSE) ) stop(paste("Unauthorized value for", Rtest), call.=TRUE)
  if( !is.logical(rasterPlot) ) stop("rasterPlot should be TRUE or FALSE", call.=TRUE)
  if( !is.logical(export) ) stop("export should be TRUE or FALSE", call.=TRUE)
  if( !is.logical(iperm) ) stop("iperm should be TRUE or FALSE", call.=TRUE)
  if( !is.numeric(B) ) stop("B should be an integer", call.=TRUE)
  if( !is.numeric(num_threads) ) stop("num_threads should be an integer", call.=TRUE)
  if( !match(statistical_value, c('T','H'), 'nomatch'=FALSE) ) stop("statistical_value should be 'T' or 'H'", call.=TRUE)
    if(!is.list(TW)) stop("TW should be a list with names A, L and len", call.=TRUE)
    if (!is.matrix(DataNeur)) stop("DataNeur should be a matrix", call.=TRUE)
                                        #  if (! match(c("DN","titlename","xrange","ntrials"), names(DataNeur), nomatch='FALSE')) warning("DataNeur should be a list with fields DN, titlename, xrange and ntrials")

    Rcode <- "neuro-stat"
                                        #
    if (iperm)   sim_name <- "Perm"
    if (!iperm)  sim_name <- "MTGAUE"
##  titlename <- paste(DataNeur$name, '-', sim_name, '-nw=', as.character(TW$len), '-', Rcode, '-', Rtest, sep='')
  title <- makeTitle(DName, sim_name, delay, level, TW$len, Rtest, Rcode, withCode=FALSE)
#  message(paste('Figure title is', title,sep='\n'))
                                        #  print(paste(zz,title))
    
  print("")
  print(paste('The value of delay for coincidences (denoted by delta in MTGAUE paper) is',as.character(delay)))
  print(paste('The level value in Benjamini-Hochberg procedure is',as.character(level)))
  print("")
  if ((!export) & (rasterPlot)) print("Plotting figures ...")
  if(export) {
    print("Exporting figures to png format ...")
    rasterPlot = TRUE #necessary for export but the user sees nothing
  }
  
  #open png output file
if(export) png(paste(gsub(' ','',gsub('\n',',',gsub('.','_',title,fixed=TRUE))),'.png',sep=''))
  
                                        #  print('export')  
  
  
  # plot of spikes of each neuron
  #  print('avt spikes.plot');print(rasterPlot)

#  xrange <- DataNeur$xrange #c(0,maxtime(NeuDataFiles))
#  yrange <- c(-50,2*DataNeur$ntrials +2) #c(-50,2*nrow(DN[[1]])+2)
        xrange <- minmaxtimes(DataNeur) 
        yrange <- c(-50,nrow(DataNeur) +2)
  if(is.null(xrange)) warning('xrange is null', call.=TRUE)
  if (rasterPlot) spikes.plot(DataNeur, n=2, xrange=xrange, yrange=yrange, title=title)
  
  
#      print("pwd")
      load_neurostatpath(neurostatpath)
      
  print("")
  
  # MulTestsBH - BH procedure
  print(paste('There are', as.character(ncol(TW$A)), 'time windows'))
#  TWO = vector('list')
  # iperm is for permutation
#  print('IPERM')
#  print(iperm)
                                        #Rtest is for symmetric MTGAUE  (or upper MTGAUE or lower MTGAUE)
  At <- MulTestsBH(DataNeur, TW$A, delay, level,  Rtest=Rtest, iperm=iperm, B=B, num_threads=num_threads, statistical_value=statistical_value)
  
  #plotting coincident spikes and detected windows
#  if (length(At))  {
          UEc = findUE(At[[1]], DataNeur, delay)
#          print('Avt plotcoinc')
#          print(length(At))
          if (rasterPlot)  UE.plot(At[[1]], UEc, nrow(DataNeur)/2, xrange, yrange)
#  }
#  else
#      UEc = list(N1= c(), N2= c())

  # closing png file if export
  if (export)  dev.off()
  return(list(A = At[[1]], UE = UEc, pval= At[[2]], M=At[[3]]))
}
#

.onLoad <- function(libname, pkgname){
#    packageStartupMessage(paste(" =========================================================================================
#Loading UnitEvents.\n
#Warning: UnitEvents package strongly relies on neuro-stat code. See https://github.com/ybouret/neuro-stat.
#During the  installation of UnitEvents package, the neuro-stat code has been downloaded and compiled under", paste(specificpath(),'UnitEvents','neuro-stat',sep='/'),".\nBut you may change the path of neuro-stat in the call of UnitEvents function by defining neurostatpath variable.\n "))

    gitc = system.file("extdata", "GITCOMMIT", package="UnitEvents")
    gc = readLines(gitc, -1)
    az = grep('branch', gc,value=TRUE)
    i = regexpr(' ',az[1], fixed=TRUE)
    branch = gsub(' ','',substring(az[1],1,i-1))
    az = grep('commit', gc, value=TRUE)
    i = regexpr(' ',az[1], fixed=TRUE)
    gitcommit = gsub(' ','',substring(az[1],i+1,nchar(az[1])))
    az = grep('version', gc, value=TRUE)
    i = regexpr('version ',az[1], fixed=TRUE)
    pversion = gsub(' ','',substring(az[1],i+nchar('version')+1,nchar(az[1])))
    az = grep('Date', gc, value=TRUE)
    i = regexpr(' ',az[1], fixed=TRUE)
    j = max(regexpr('+0100',az[1], fixed=TRUE), regexpr('+0200',az[1], fixed=TRUE)) # depends on the date
    Date = substring(az[1],i+1,j-1)
    c1 = paste('UnitEvents package - version', pversion)
    c2 = paste(branch,'branch -','commit', substring(gitcommit,1,12),'-',Date)
    c3 = paste('See https://github.com/ybouret/neuro-stat for neuro-stat code')

    packageStartupMessage(paste("==========================================================================================",c1,'',c2,'',c3,sep='\n'))

                                        #    load_neurostatpath('')

}

.onAttach <- function(libname, pkgname){
    load_neurostatpath('')
}

