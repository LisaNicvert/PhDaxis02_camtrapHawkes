                                        # To draw time windows (in yellow color, by default)
                                        #A1t may be a matrix (a time window matrix) or a list of time window type (with fields A, dt and len)
                                        # after BH test
draw_windows <- function(A, xrange, yrange, col="yellow", density="", border="black")
{
                                        #    print(paste('dim A',as.character(length(A))))
    if((!is.list (A)) && (!is.matrix(A))) stop("A should be a list or a matrix", call.=TRUE)
    if (is.list(A))
    {
        if(!is.element("A", names(A))) stop("List should contain field \"A\"", call.=TRUE)
        A = A$A   #
    }
                                        #            if( (!is.null(A)) & ( !is.matrix(A) ) ) stop("A should be a matrix (time window matrix)", call.=TRUE)
                                        #    print(A)
    xmin <- suppressWarnings(min(A, na.rm=TRUE));  xmax <- suppressWarnings(max(A, na.rm=TRUE))
    if((!is.finite(xmin))  || (!is.finite(xmax))) A <- NULL

    if( (!is.null(A)) && (ncol(A)>0))
    {
                                        #            if(!is.null(dev.list())) par(new=TRUE)

                                        #  print(paste('Number of columns of A',as.character(ncol(A))))
        
        ypmax <- 0  # maximum y-value for detected window polygon
        
        if(missing(xrange))
            xrange = c(xmin, xmax)
        if(missing(yrange))
            yrange = c(ypmax-25, ypmax)

        plot(c(1), type="n", xlim=xrange, ylim=yrange, xlab="time in seconds", ylab="", las=1)
        
        pdraw <- c()
        imod = 20
                                        #  #{
                                        #  #pdraw=c(pdraw,c(A[1,i],-75,A[1,i],-50))
                                        #  #pdraw=c(pdraw,c(A[2,i],-50,A[2,i],-75))
                                        #  #}
        ##   plot(c(1), type="n", xlim=xrange, ylim=c(ypmax-25*ncol(A),ypmax), xlab="time in seconds", ylab="")
                                        #   plot(c(1), type="n", xlim=xrange, ylim=c(ypmax-25*(ncol(A)%%imod),ypmax), xlab="time in seconds", ylab="")

        for (i in 1:ncol(A))
        {
            par(new=TRUE)
            pdraw = c(A[1,i], A[1,i], A[2,i], A[2,i], max(ypmax-25, min(yrange)), ypmax, ypmax, max(ypmax-25, min(yrange)))
                                        #      pdraw = c(A[1,i], A[1,i], A[2,i], A[2,i], ypmax-25*(i%%imod), ypmax-25*((i-1)%%imod), ypmax-25*((i-1)%%imod), ypmax-25*(i%%imod))

            pdraw <- matrix(pdraw,ncol=2)
                                        #      polygon(pdraw,col='yellow',border=NA)  #no border
            polygon(pdraw, col=col, border=border, density=density)
            rm(pdraw)
        }
    }
    else
        warning("Empty matrix => no plot!")
}



                                        # To plot coincident spikes and detected windows
                                        #
UE.plot <- function(A, UE, ntrials, xrange, yrange, col=c('red','blue'))
{
    if(!is.character(col)) 
    {
        warning('Colors set to red and blue for plotting UEs', call.=TRUE)
        col=c('red', 'blue')
    }
    if(length(col)==1) 
    {
        warning('Only one color given for plotting UEs', call.=TRUE)
        col=c(col[1], col[1])
    }
    if(!is.null(dev.list())) par(new=TRUE)
    if(length(A))
    {
        if(missing(xrange))
            xrange = c(min(A[1,]), max(A[2,]))

        if(missing(yrange))
            yrange = c(-50, 2*max(UE$N1[2,], UE$N2[2,]))

        iup = which(UE$N1[3,] == 1)
        jup = which(UE$N2[3,] == 1)
        idown = which(UE$N1[3,] == -1)
        jdown = which(UE$N2[3,] == -1)
                                        #    if(norm(as.matrix(iup-jup))>0) stop(print(norm(as.matrix(iup-jup))), call.=TRUE)
                                        #    if(norm(as.matrix(idown-jdown))>0) stop(print(norm(as.matrix(idown-jdown))), call.=TRUE)
                                        #    stopifnot(norm(as.matrix(idown-jdown))==0)
        if(length(iup))
        {
            plot(UE$N1[1,iup], UE$N1[2,iup], pch=16, col='red', xlim=xrange, ylim=yrange, xlab='', ylab='', las=1)
            par(new=TRUE)
        }
        if(length(idown))
        {
            plot(UE$N1[1,idown], UE$N1[2,idown], pch=16, col='blue', xlim=xrange, ylim=yrange, xlab='', ylab='', las=1)
            par(new=TRUE)
        }
        if(length(jup))
        {
            plot(UE$N2[1,jup], UE$N2[2,jup]+ntrials+1, pch=16, col='red', xlim=xrange, ylim=yrange, xlab='', ylab='', las=1)
            par(new=TRUE)
        }
        if(length(jdown))
        {
            plot(UE$N2[1,jdown], UE$N2[2,jdown]+ntrials+1, pch=16, col='blue', xlim=xrange, ylim=yrange, xlab='', ylab='', las=1)
            par(new=TRUE)
        }
    }
    draw_windows(A, xrange, yrange, border=NA)
    par(new=FALSE)
}



                                        #                                        # To plot the spikes of each neuron.
                                        #                                        # Spikes of the first neuron are represented at the bottom in grey color, while spikes of the second neuron are represented at the top in green color. There is a red separation line.
                                        #                                        #
                                        #spikes.plot.old <- function(DataNeur, xrange, yrange, title='', col=c('gray','green3'))
                                        #{
                                        #                                        #  print(paste('F1 -',typeof(F1)))
                                        #    n <- DataNeur$ntrials
                                        #                                        #  print(n)
                                        #    F1 <- DataNeur$DN[[1]]
                                        #    F2 <- DataNeur$DN[[2]]
                                        #    
                                        #    if(missing(xrange))
                                        #        xrange = minmaxtime(DataNeur)
                                        #
                                        #                                        #print(xrange)
                                        #    if(missing(yrange))
                                        #        yrange = c(-50, 2*n+2)
                                        #    if(nrow(F1)==1)
                                        #        xi <- which(t(as.matrix(F1[,-1]))!=0, arr.ind=TRUE)  # transpose used here !!!
                                        #    else  
                                        #        xi <- which(F1[,-1]!=0, arr.ind=TRUE)
                                        #    xi[,2] = xi[,2] + 1
                                        #    plot(F1[xi], xi[,1], pch=16, xlim=xrange, ylim=yrange, xlab="time in seconds", ylab="trials", col=col[1], las=1)
                                        #    mtext(side=2, at=c(round((n+1)/2)), "N1", las=1, line=0.5, col=col[1])
                                        #    par(new=TRUE)
                                        #    if(nrow(F2)==1)
                                        #        xi <- which(t(as.matrix(F2[,-1]))!=0, arr.ind=TRUE)  # transpose used here !!!
                                        #    else  
                                        #        xi <- which(F2[,-1]!=0, arr.ind=TRUE)
                                        #    xi[,2] = xi[,2] + 1
                                        #    plot(F2[xi], (n+1)+xi[,1], pch=16, xlim=xrange, ylim=yrange, xlab="time in seconds", ylab="trials", col=col[2], las=1)
                                        #    mtext(side=2, at=c(round((3*n+3)/2)), "N2", las=1, line=0.5, col=col[2])
                                        #    title(main=title)
                                        #    par(new=TRUE)
                                        #}
                                        #
                                        # To create a smart title for the figures of the simulation.
                                        # withCode serves for giving the code name used in the simulation
makeTitle <- function(name="Neuron", sim_name="MTGAUE", delay=0., level=0., nw=0, Rtest="symmetric", Rcode="neuro-stat", withCode=FALSE)
{
    line1 = paste("Raster plot for", name)  #first line of the title (with neuron name and type of the computation (MTGAUE, permutation, ...))
    if(withCode)
        line2 = paste(paste("type =", sim_name), paste("delay=",as.character(delay),sep=''), paste("level=", as.character(level),sep=''), paste("nw=", as.character(nw),sep=''), paste("Rtest=", Rtest,sep=''), paste("code=", Rcode,sep=''), sep=", ")
    else
        line2 = paste(paste("type =", sim_name), paste("delay=",as.character(delay),sep=''), paste("level=", as.character(level),sep=''), paste("nw=", as.character(nw),sep=''), paste("Rtest=", Rtest,sep=''), sep=", ")
    t = paste(line1, line2, sep="\n")
    return(t)
}

                                        # To plot neuron spikes.
                                        # Spikes of the first neuron are represented at the bottom in grey color, while spikes of the second neuron are represented at the top in green color. 
                                        #
                                        #spikes.plot <- function(DataNeur, v=1:n, n, xrange, yrange, title='', col=c('gray','green3'), DNVersion='matrix')
spikes.plot <- function(DataNeur, v, n, xrange, yrange, title='', col=c('gray','green3'))
{
    if(!is.character(col)) 
    {
#        warning('Colors set to gray and green3 for plotting spikes', call.=TRUE)
        message('Colors set to gray and green3 for plotting spikes in spikes.plot function')
        col = c('gray', 'green3')
    }

#    if ((missing(c(v,n)))) 
    if ((missing(v)) && (missing(n))) 
    {   
        n = 1; v = c(1)
    } else
    {
        if(missing(v)) v = c(1:n)
        else
            if(missing(n)) n = max(v)
    }

    if(length(col)!=length(v)) 
    {
#        warning('Uncorrect number of colors given for plotting spikes', call.=TRUE)
        message('Uncorrect number of colors given for plotting spikes in spikes.plot function')
                                        #            print(col)
        col = rep(col[1], length(v))
    }
                                        #    if(missing(n))
                                        #        stop('Missing information in spikes.plot', call.=TRUE)
                                        #    if(DNVersion=="matrix")
                                        #        {
    if(missing(xrange) && missing(yrange))
        spikes.plot.matrix(DataNeur, v, n, title=title, col=col)
    else
        if(missing(xrange))
            spikes.plot.matrix(DataNeur, v, n, yrange=yrange, title=title, col=col)
    else
        if(missing(yrange))
            spikes.plot.matrix(DataNeur, v, n, xrange=xrange, title=title, col=col)
    else
        spikes.plot.matrix(DataNeur, v, n, xrange, yrange, title=title, col=col)

                                        #        }
}



                                        # To plot neuron spikes.
                                        # Spikes of the first neuron are represented at the bottom in grey color, while spikes of the second neuron are represented at the top in green color.
                                        #
spikes.plot.matrix <- function(DataNeur, v, n, xrange, yrange, title='', col=c('gray','green3'))
{
    stopifnot(length(v)<=n)
    ntrials = nrow(DataNeur)/n
    
    if(missing(xrange))
        xrange = minmaxtimes(DataNeur) #minmaxtime(DataNeur)

    if(missing(yrange))
        yrange = c(0, n*ntrials+n) #c(-50, n*ntrials+n)
                                        #    print(c(n,ntrials,col))
    
    plot.single<- function(i) {spikes.plot.single(DataNeur, i, n, xrange, yrange, col=col[which(v==i)])}

    sapply(v, plot.single)
    title(main=title)
    par(new=TRUE)
}

                                        # To plot the spikes of only one neuron (DNVersion='matrix')
                                        #
spikes.plot.single <- function(DataNeur, i, n, xrange, yrange, col='gray')
{
    stopifnot(i<=n)
    if(!is.character(col)) 
        col=c('gray')

    ntrials <- nrow(DataNeur)/n #number of trials
    
                                        #    browser()
    F <- DataNeur[((i-1)*ntrials+1):(i*ntrials),] #

    if(nrow(F)==1)
        xi <- which(t(as.matrix(F[,-1]))!=0, arr.ind=TRUE)  # transpose used here !!!
    else  
        xi <- which(F[,-1]!=0, arr.ind=TRUE)
                                        #    print(xi)
    xi[,2] = xi[,2] + 1
    plot(F[xi], xi[,1]+(i-1)*(ntrials+1), pch=16, xlim=xrange, ylim=yrange, xlab="time in seconds", ylab="trials", col=col, las=1)
    mtext(side=2, at=round((i-1/2)*(ntrials+1)), paste("N", as.character(i), sep=''), las=1, line=0.5, col=col)
    par(new=TRUE)
}
