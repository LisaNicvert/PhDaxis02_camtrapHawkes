# demo for the package UnitEvents
#
UEdemo <- function()
{

#library('UnitEvents')
#library(stringr)
load_neurostatpath("")
resC = file.copy(paste(specificpath(), 'UnitEvents', 'data', c('Neur1_c13.txt.gz','Neur2_c13.txt.gz','Neur1_c40.txt.gz','Neur2_c40.txt.gz'),sep='/') , '.')
if(any(!resC)) warning('At least one example file has not been copied (already exists)', call.=TRUE)
system('gunzip Neur*.txt.gz')
                                        #par(mfrow=c(2,2))
print("MTGAUE test for Neuron 13")
#xns13 = UnitEvents(delay=0.02, export=TRUE)
#TW = compute_time_windows(a=1e-3, b=2, duration=0.1, spacing=0.05)
TW = compute_time_windows(a=0, b=2.05, duration=0.1, spacing=0.05)
rmcols <- function(v) { return(v[-c(1,(length(v)-6):length(v))])}
scaling <- 1/10000
D13 = DNeur(list("Neur1_c13.txt","Neur2_c13.txt"), listOptions=list('removeCols'=rmcols, 'scaling'=scaling))
D40 = DNeur(list("Neur1_c40.txt","Neur2_c40.txt"), listOptions=list('removeCols'=rmcols, 'scaling'=scaling))
xns13 = UnitEvents(delay=0.02, TW=TW, DataNeur=D13, DName="Neur_c13")
dev.new()
print("MTGAUE test for Neuron 40")
#par(new=TRUE)
xns40 = UnitEvents(delay=0.02, TW=TW, DataNeur=D40, DName="Neur_c40")
dev.new()
print("Permutation test for Neuron 13")
#par(new=TRUE)
xns13P = UnitEvents(delay=0.02, TW=TW, iperm=TRUE, DataNeur=D13, DName="Neur_c13")
dev.new()
print("Permutation test for Neuron 40")
#par(new=TRUE)
xns40P = UnitEvents(delay=0.02, TW=TW, DataNeur=D40, iperm=TRUE, DName="Neur_c40")
return(list(xns13, xns40, xns13P, xns40P))
}
