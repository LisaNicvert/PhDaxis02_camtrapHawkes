BoxLasso<-function(DataNeur, Nneur, scale, del, k, BoxEst, gamma=3, Z=0.15, threads=4)
{
    NeuroCorr_SetParallel(threads)
    
    GbVB = NeuroCorr_Compute(DataNeur, Nneur, scale, del, k, BoxEst, "byKind")
    Ncomp = length(GbVB$mu1)
    
    BL = lapply(1:Ncomp, FUN=function(comp)
    {
        coeff = NeuroCorr_Coeff(GbVB$G[[comp]],GbVB$mu1[[comp]],GbVB$mu2[[comp]],GbVB$muA[[comp]],gamma)
        return(coeff$a)
    })
    BOL = lapply(1:Ncomp, FUN=function(comp)
    {
        sapply(1:Nneur, FUN=function(nneur)
        {
            poscoeff = which(abs(BL[[comp]][,nneur])>0) # determination of the support
            a_BO = 0*as.matrix(BL[[comp]][,nneur])
            if (length(poscoeff)!=0)
            {
                Gpos = GbVB$G[[comp]][poscoeff,poscoeff] # G restricted to the support
                a_BO[poscoeff] = solve(Gpos)%*%as.matrix(GbVB$mu1[[comp]][poscoeff,nneur]) #inversion ie OLS solution on the support
            }
            return(a_BO)
        })
    })
    
    mat1 = matrix(1, nrow=Nneur, ncol=Nneur) - diag(rep(1,Nneur))
    
    if(Nneur>1)
    {
        BVL = lapply(1:Ncomp, FUN=function(comp)
        {
            mint = matrix(0, nrow=Nneur, ncol=Nneur)
            for(nneur2 in 1:Nneur)
            {
                if(k>1)
                {mint[,nneur2] = colSums(BOL[[comp]][(k*(nneur2-1)+2):(k*nneur2+1),]*del)}
                else{mint[,nneur2] = BOL[[comp]][(k*(nneur2-1)+2):(k*nneur2+1),]*del}
                
            }
            mint_Inter = mat1*mint
            
            indice = which(mint_Inter>0)
            if(length(indice)>0)
            {
                exc = mint_Inter[indice]
                exc_sort = sort(exc)
                exc_sortbis = c(0, exc_sort)
                saut = diff(exc_sortbis)
                indlim = min(which(saut>Z*max(saut)))
                
                if(indlim>1)
                {
                    seuil = exc_sort[indlim-1]
                    
                }else{seuil = 0}
            }else{seuil = 0}
            
            adj_mat = 1*(mint>seuil) + 1*(mint<0)
            
            res = BOL[[comp]]
            for(nneur2 in 1: Nneur)
            {
                res[(k*(nneur2-1)+2):(k*nneur2+1),] = res[(k*(nneur2-1)+2):(k*nneur2+1),]%*%diag(adj_mat[,nneur2])
            }
            
            return(res)
        })
        
        return(list(BL=BL, BOL=BOL, BVL=BVL))
    }else{
        return(list(BL=BL, BOL=BOL))
    }
    
    
}
