myfunc <- function(i, df)
    {
        v = df[df[,1]==i,2]
        return(c(length(v), as.numeric(v)))
    }

createDN <- function(fname)
    {
        df = read.csv2(fname, header=TRUE, sep=",", stringsAsFactors=FALSE)
#        nneur = length(unique(df[,1]))
        nneur = max(df[,1]) + 1  # indices start from 0
        vl = vector("list", length=nrow(df))
        mmax = -1
        for(i in seq_len(nneur))
            {
                vl[[i]] = myfunc(i-1, df)      
                mmax = max(mmax, length(vl[[i]]))
            }
#        DN = matrix(NA, nrow=nrow(df), ncol=mmax)
        DN = matrix(0, nrow=nneur, ncol=mmax)
        for(i in seq_len(nneur))
            {
                DN[i, 1:(vl[[i]][1]+1)] = vl[[i]]
            }
                                        #                return(vl)
        return(DN)
                                        #print(vl[[3]])
        
                                        #            DN = matrix(unlist(vl))
                                        #            return(DN)
    }


