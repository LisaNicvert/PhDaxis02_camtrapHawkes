                                        #-----------------------------------------
                                        #The function compute_pvalues computes the p-value associated to the GAUE symmetric test and the numerator of this test.
                                        #The arguments of this function are:
                                        #  - C: a three-value array. It contains the mean of the coincidence count and the two firing rate estimators ( see the ouput of wink_coincmat function)
                                        #  - ntrials: the number of trials of the datasets used to compute the average coincidence count with delay
                                        #  - a and b: the lower limit and the upper limit of the time window on with C is computed
                                        #  - delay: the delay

                                        #The output of this function is a list with two elements, the first one is the p-value associated to the GAUE symmetric test
                                        #and the second one is th enumerator of the statistic test.
                                        #------------------------------------------

compute_pvalues <- function(C, ntrials, a, b, delay, test="all")
{
    c = 2*delay*(b-a)-delay^2
    l1hat = C[2]
    l2hat = C[3]

    T1 = sqrt(ntrials)*(C[1] - c*l1hat*l2hat)
    T2 = l1hat*l2hat*(c + (2/3*delay^3 - delay^4/(b-a)) * (l1hat+l2hat))

    eps = 1e-8  # numerical precision
    if(abs(l1hat*l2hat)<1e-8) {
            stopmsg = 'Computation halted.'
            if(abs(l1hat)<1e-8)
                stopmsg = paste(stopmsg, 'Firing rate of the first neuron is 0.')
            if(abs(l2hat)<1e-8)
                stopmsg = paste(stopmsg, 'Firing rate of the second neuron is 0.')
            stop(stopmsg, call.=TRUE)
        }

        stopifnot(T2>0)
    T = T1/sqrt(T2) #statistic
    if (test=="all") {
        pvp = pnorm(T, mean = 0, sd = 1)
        pvm = pnorm(-T, mean = 0, sd = 1)
        alpha = c(1-pvp, 1-pvm)
        T1 = rep(T1, 2)
    }

    if (test=="symmetric") {
        pv = pnorm(abs(T),mean = 0, sd = 1)
        alpha = 2*(1-pv)	#alpha is the pvalue
    }

    if (test=="upper") {
        pv = pnorm(T, mean = 0, sd = 1)
        alpha = 1 - pv	#alpha is the pvalue
    }

    if (test=="lower") {
#        pv = pnorm(-T, mean = 0, sd = 1)
#        alpha = 1 - pv 	#alpha is the pvalue
        pv = pnorm(T, mean = 0, sd = 1)
        alpha = pv 	#alpha is the pvalue
    }
#    compute_pvalues <- list(alpha, T1, T)
    compute_pvalues <- list(alpha, T1)
}

